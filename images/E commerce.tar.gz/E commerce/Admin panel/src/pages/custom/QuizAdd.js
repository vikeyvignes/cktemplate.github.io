import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { Col, Row, Button, Card, Form } from '@themesberg/react-bootstrap';

// import packages
import isEmpty from 'is-empty';


// import actions
import { addQuiz } from '../../actions/categoryActions';

// import lib
import toastAlert from '../../lib/toaster';

const initialFormValue = {
    'question': '',
    'correctanswer': '',
    'option1': '',
    'option2': '',
    'option3': '',
    'option4': '',
}
export default () => {

    // hooks
    const navigate = useHistory();


    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState({});
    const { question, correctanswer, option1, option2, option3, option4 } = formValue;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValue({ ...formValue, ... { [name]: value } })
    }

    const handleSubmit = async () => {
        try {
            let data ={
              question :question,
              correctanswer:correctanswer,
              option1:option1,
              option2:option2,
              option3:option3,
              option4:option4
            } 
            let { status, message, errors } = await addQuiz(data);

            if (status === true) {
                toastAlert('success', message)
                setFormValue(initialFormValue)
                setErrors({});
                // navigate.push('/category-list')
            } else if (status === false) {
                if (errors) {
                    setErrors(errors);
                }

                if (message) {
                    toastAlert('error', message)
                }
            }
        } catch (err) { }
    }

    const isValid = (errName) => {
        return !isEmpty(errName);
    }

    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
            </div>

            <Row>
                <Col xs={12} xl={12}>
                    <Card border="light" className="bg-white shadow-sm mb-4">
                        <Card.Body>
                            <h5 className="mb-4">Quiz</h5>
                            <Form>
                                <Row>
                                    <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Question</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.question) && isValid(errors.question)} placeholder="Enter your question" name='question' value={question} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.question}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Correctanswer</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.correctanswer) && isValid(errors.correctanswer)} placeholder="Enter your correctanswer" name='correctanswer' value={correctanswer} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.correctanswer}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Option1</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.option1) && isValid(errors.option1)} placeholder="Enter option1" name='option1' value={option1} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.option1}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Option2</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.option2) && isValid(errors.option2)} placeholder="Enter your option2" name='option2' value={option2} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.option2}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>option3</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.option3) && isValid(errors.option3)} placeholder="Enter your  option3" name='option3' value={option3} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.option3}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>option4</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.option4) && isValid(errors.option4)} placeholder="Enter your  option4" name='option4' value={option4} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.option4}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <div className="mt-3">
                                    <Button variant="primary" type="button" onClick={handleSubmit}>Save</Button>
                                </div>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};
