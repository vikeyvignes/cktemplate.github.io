import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Card, Table, Button } from '@themesberg/react-bootstrap';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faPencilAlt } from "@fortawesome/free-solid-svg-icons";


// import actions
import { getCarousel } from '../../actions/carouselActions';
import { deleteCarousel } from '../../actions/carouselActions';


//import lib
import toastAlert from '../../lib/toaster'

export default () => {

    // hooks
    const navigate = useHistory();


    const [data, setData] = useState([]);
    const [IMAGE_URL, SET_IMAGE_URL] = useState('');

    const TableRow = (props) => {

        const { _id, offername, name, image } = props;
        return (
            <tr>
                <td>
                    <span className="fw-normal">
                        {(offername)}
                    </span>
                </td>
                <td>
                    <span className="fw-normal">
                        {(name)}
                    </span>
                </td>
                <td>
                    <span className="fw-normal">
                        <a href={`${IMAGE_URL}/${image}`} target="_blank" ><img src={`${IMAGE_URL}/${image}`} style={{ 'width': '70px' }} /></a>
                    </span>
                </td>
                <td>
                    <Button
                        variant="secondary"
                        className="m-1"
                        onClick={() => editcarousel(_id)}>
                        <FontAwesomeIcon icon={faPencilAlt} className="me-2" />
                        Edit
                    </Button>
                    <Button
                        variant="danger"
                        className="m-1"
                        onClick={() => deletecarousel(_id)}>
                        <FontAwesomeIcon icon={faTrashAlt} className="me-2" />
                        Delete
                    </Button>
                </td>
            </tr>
        );
    };

    const editcarousel = (id) => {
        navigate.push('/edit-carousel/' + id)
    }


    const deletecarousel = async (id) => {
        try {

            let { status, message } = await deleteCarousel(id)

            if (status === true) {
                toastAlert('success', message)
                getData()

            } else if (status === false) {
                toastAlert('success', message)
            }

        } catch (err) {

        }
    }


    const getData = async () => {
        try {

            let { status, result, imageUrl } = await getCarousel()

            if (status === true) {
                setData(result)
                SET_IMAGE_URL(imageUrl)

            }

        } catch (err) {

        }
    }

    useEffect(() => {
        getData()
    }, [])



    const addcarousel = () => {
        navigate.push('/carousel-add')
    }


    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
                <div className="d-block mb-4 mb-md-0">
                    <h4>Carousel List</h4>
                </div>
                <div className="d-block mb-4 mb-md-0">
                    <Button variant="outline-primary" className="m-1" onClick={addcarousel}>Add Carousel</Button>
                </div>
            </div>

            <Card border="light" className="table-wrapper table-responsive shadow-sm">
                <Card.Body className="pt-0">
                    <Table hover className="user-table align-items-center">
                        <thead>
                            <tr>
                                <th className="border-bottom">Offer Name</th>
                                <th className="border-bottom">Name</th>
                                <th className="border-bottom">Image</th>
                                <th className="border-bottom">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                data.map((item) => TableRow(item))
                            }
                        </tbody>
                    </Table>
                    <Card.Footer className="px-3 border-0 d-lg-flex align-items-center justify-content-between">
                    </Card.Footer>
                </Card.Body>
            </Card>
        </>
    );
};
