import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Card, Table, Button, Badge } from '@themesberg/react-bootstrap';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faPencilAlt } from "@fortawesome/free-solid-svg-icons";


// import actions
import { getProduct, statusUpdate } from '../../actions/productActions';
import { deleteProduct } from '../../actions/productActions';

// import config
import config from '../../config';


//import lib
import toastAlert from '../../lib/toaster'



export default () => {

  // hooks
  const navigate = useHistory();


  // const totalTransactions = transactions.length;

  const [data, setData] = useState([]);
  const [IMAGE_URL, SET_IMAGE_URL] = useState('');
  // const [count, setCount] = useState(0);
  const TableRow = (props) => {

    const { _id, name, price, availableQty, image, categoryId, status } = props;
    return (
      <tr>
        <td>
          <span className="fw-normal">
            {(categoryId && categoryId.name)}
          </span>
        </td>
        <td>
          <span className="fw-normal">
            {(name)}
          </span>
        </td>
        <td>
          <span className="fw-normal">
            {(price)}
          </span>
        </td>
        <td>
          <span className="fw-normal">
            {(availableQty)}
          </span>
        </td>
        <td>
          <span className="fw-normal">
            <a href={`${IMAGE_URL}/${image}`} target="_blank" ><img src={`${IMAGE_URL}/${image}`} style={{ 'width': '70px' }} /></a>
          </span>
        </td>
        <td>
          <Badge
            pill={true}
            bg="success"
            className="me-1"
            onClick={() => handleChangeStatus(_id)}>
            {status}
          </Badge>
        </td>
        <td>
          <Button
            variant="secondary"
            className="m-1"
            onClick={() => editproducts(_id)}>
            <FontAwesomeIcon icon={faPencilAlt} className="me-2" />
            Edit
          </Button>
          <Button
            variant="danger"
            className="m-1"
            onClick={() => deleteproducts(_id)}>
            <FontAwesomeIcon icon={faTrashAlt} className="me-2" />
            Delete
          </Button>
        </td>
      </tr>
    );
  };

  const editproducts = (id) => {
    navigate.push('/edit-product/' + id)
  }


  const deleteproducts = async (id) => {
    try {

      let { status, message } = await deleteProduct(id)

      if (status === true) {
        toastAlert('success', message)
        getData()

      } else if (status === false) {
        toastAlert('success', message)
      }

    } catch (err) {

    }
  }

  const handleChangeStatus = async (id) => {
    try {
      let data = { id }
      let { status, message } = await statusUpdate(data)
      if (status === true) {
        toastAlert('success', message)
        getData()
      }

      if (status === false) {
        toastAlert('success', message)
      }
    } catch (err) {

    }
  }

  const getData = async () => {
    try {

      let { status, result, imageUrl } = await getProduct()

      if (status === true) {
        setData(result)
        SET_IMAGE_URL(imageUrl)
      }

    } catch (err) {

    }
  }

  useEffect(() => {
    getData()
  }, [])



  const addproducts = () => {
    navigate.push('/product-add')
  }


  return (
    <>
      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
        <div className="d-block mb-4 mb-md-0">
          <h4>Product List</h4>
        </div>
        <div className="d-block mb-4 mb-md-0">
          <Button variant="outline-primary" className="m-1" onClick={addproducts}>Add Products</Button>
        </div>
      </div>

      <Card border="light" className="table-wrapper table-responsive shadow-sm">
        <Card.Body className="pt-0">
          <Table hover className="user-table align-items-center">
            <thead>
              <tr>

                <th className="border-bottom">Category Name</th>
                <th className="border-bottom">Name</th>
                <th className="border-bottom">Price</th>
                <th className="border-bottom">AvailableQuantity</th>
                <th className="border-bottom">Image</th>
                <th className="border-bottom">Status</th>
                <th className="border-bottom">Action</th>
              </tr>
            </thead>
            <tbody>

              {
                data.map((item) => TableRow(item))
              }
            </tbody>
          </Table>
          <Card.Footer className="px-3 border-0 d-lg-flex align-items-center justify-content-between">
            {/* <Nav>
              <Pagination className="mb-2 mb-lg-0">
                <Pagination.Prev>
                  Previous
                </Pagination.Prev>
                <Pagination.Item active>1</Pagination.Item>
                <Pagination.Item>2</Pagination.Item>
                <Pagination.Item>3</Pagination.Item>
                <Pagination.Item>4</Pagination.Item>
                <Pagination.Item>5</Pagination.Item>
                <Pagination.Next>
                  Next
                </Pagination.Next>
              </Pagination>
            </Nav> */}
            {/* <small className="fw-bold">
              Showing <b>{count}</b> out of <b>25</b> entries
            </small> */}
          </Card.Footer>
        </Card.Body>
      </Card>
    </>
  );
};
