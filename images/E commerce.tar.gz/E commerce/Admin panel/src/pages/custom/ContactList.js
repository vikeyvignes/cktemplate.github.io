import React, { useEffect, useState, Fragment } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Card, Table, Button } from '@themesberg/react-bootstrap';
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import ReactDatatable from '@ashvin27/react-datatable';



// import actions
import { getContact } from '../../actions/euserAction';


export default () => {


  // hooks
  const navigate = useHistory();

  const [data, setData] = useState([]);
  const [count, setCount] =  useState(0);
  // const TableRow = (props) => {

  //   const { _id,name, email, subject, message } = props;
  //   return (
  //     <tr>
  //       <td>
  //         <span className="fw-normal">
  //           {(name)}
  //         </span>
  //       </td>
  //       <td>
  //         <span className="fw-normal">
  //           {(email)}
  //         </span>
  //       </td>
  //       <td>
  //         <span className="fw-normal">
  //           {(subject)}
  //         </span>
  //       </td>
  //       <td>
  //         <span className="fw-normal">
  //           {(message)}
  //         </span>
  //       </td>
  //       <td>
  // <Button
  //   variant="secondary"
  //   className="m-1"
  //   onClick={() => viewmessage(_id)}>
  //   <FontAwesomeIcon icon={faEnvelope} className="me-2" />
  //   Email
  // </Button>
  //       </td>
  //     </tr>
  //   );
  // };

  const viewmessage = (id) => {
    navigate.push('/user-message/' + id)
  }

  const getData = async (reqDoc) => {
    try {

      let { status, result } = await getContact(reqDoc)

      if (status === true) {
        setData(result.records)
        setCount(result.count)
      }

    } catch (err) {

    }
  }

  useEffect(() => {
    let reqDoc = {
      'page': 1,
      'limit': 10,
      'search': ''
    }
    getData(reqDoc)
  }, [])

  const columns = [
    {
      key: "name",
      text: "Name",
      // className: <span className="fw-normal">
      // {(data.name)}</span>,
      align: "left",
      sortable: true,
    },
    {
      key: "email",
      text: "Email",
      // className: <span className="fw-normal"></span>,
      align: "left",
      sortable: true,
    },
    {
      key: "subject",
      text: "Subject",
      // className: <span className="fw-normal">
      align: "left",
      sortable: true,
    },
    {
      key: "message",
      text: "Message",
      // className: <span className="fw-normal">
      align: "left",
      sortable: true,
    },
    {
      key: "replymessage",
      text: "Replymessage",
      align: "left",
      sortable: true,
      className: "replymessage",
      cell: data => {
        return (
          <Button
            variant="secondary"
            className="m-1"
            onClick={() => viewmessage(data._id)}>
            <FontAwesomeIcon icon={faEnvelope} className="me-2" />
            Email
          </Button>)
      }
    },
  ]
  const config = {
    page_size: 10,
    length_menu: [10, 20, 50]
  }

  const handlePagination = (data) => {
    console.log(data, '----data')
    let reqDoc = {
      'page': data.page_number,
      'limit': data.page_size,
      'search': data.filter_value
    }
    getData(reqDoc)
  }

  return (
    <>
      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
        <div className="d-block mb-4 mb-md-0">
          <h4>Contact List</h4>
        </div>
      </div>
      <Card border="light" className="table-wrapper table-responsive shadow-sm">
        <Card.Body className="pt-0">
          <ReactDatatable
            config={config}
            records={data}
            columns={columns}
            dynamic={true}
            total_record={count}
            onChange={handlePagination}
          />

          {/* <Table hover className="user-table align-items-center">
            <thead>
              <tr>

                <th className="border-bottom">Name</th>
                <th className="border-bottom">Email</th>
                <th className="border-bottom">Subject</th>
                <th className="border-bottom">Message</th>
                <th className="border-bottom">Reply Message</th>
              </tr>
            </thead>
        
            <tbody>

              {
                data.map((item) => TableRow(item))
              }
            </tbody>
          </Table> */}
          <Card.Footer className="px-3 border-0 d-lg-flex align-items-center justify-content-between">
          </Card.Footer>
        </Card.Body>
      </Card>
    </>
  );
};
