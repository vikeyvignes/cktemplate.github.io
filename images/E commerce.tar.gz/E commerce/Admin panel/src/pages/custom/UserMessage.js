import React, { useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Col, Row, Button, Card, Form } from '@themesberg/react-bootstrap';

// import packages
import isEmpty from 'is-empty';


// import actions
import { UserMessage } from '../../actions/euserAction';

// import lib
import toastAlert from '../../lib/toaster';


const initialFormValue = {
    'replymessage': '',
    
}
export default () => {

    // hooks
    const navigate = useHistory();

    // params
    const { orderId } = useParams()


    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState({});
    const {replymessage } = formValue;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValue({ ...formValue, ... { [name]: value } })
    }

    const handleSubmit = async () => {
        try {
            let data = {
                replymessage :replymessage,
                orderId
            }
            
            let { status, result, errors } = await UserMessage (data);

            if (status === true) {
                toastAlert('success', result)
                setFormValue(initialFormValue)
                setErrors({});
                navigate.push('/contact-list')
            } else if (status === false) {
                if (errors) {
                    setErrors(errors);
                }

                if (result) {
                    toastAlert('error', result)
                }
            }
        } catch (err) { }
    }

    const isValid = (errName) => {
        return !isEmpty(errName);
    }

    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
            </div>

            <Row>
                <Col xs={12} xl={12}>
                    <Card border="light" className="bg-white shadow-sm mb-4">
                        <Card.Body>
                            <h5 className="mb-4">User Message</h5>
                            <Form>
                                <Row>
                                    <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Message</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.replymessage) && isValid(errors.replymessage)} placeholder="Enter your replymessage" name='replymessage' value={replymessage} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.replymessage}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <div className="mt-3">
                                    <Button variant="primary" type="button" onClick={handleSubmit}>Send</Button>
                                </div>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};
