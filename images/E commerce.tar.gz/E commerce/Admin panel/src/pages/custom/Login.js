import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { Col, Row, Button, Card, Form } from '@themesberg/react-bootstrap';

// import packages
import isEmpty from 'is-empty';


// import actions
import { login } from '../../actions/euserAction';

// import lib
import toastAlert from '../../lib/toaster';
import { setAuthToken } from '../../lib/localstorage';

//import config
import { setAuthorization } from '../../config/axios'

const initialFormValue = {
    'email': '',
    'password' : '',
}
export default () => {

    // hooks
    const navigate = useHistory();


    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState({});
    const { email, password } = formValue;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValue({ ...formValue, ... { [name]: value } })
    }

    const handleSubmit = async () => {
        try {
            let data = {
                email :email,
                password :password,
            }
            let { status, message, errors,token } = await login (data);

            if (status === true) {
                toastAlert('success', message)
                setFormValue(initialFormValue)
                setErrors({});
                setAuthToken(`Bearer ${token}`);
                setAuthorization(`Bearer ${token}`);
                navigate.push('/product-add')
            } else if (status === false) {
                if (errors) {
                    setErrors(errors);
                }

                if (message) {
                    toastAlert('error', message)
                }
            }
        } catch (err) { }
    }

    const isValid = (errName) => {
        return !isEmpty(errName);
    }

    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
            </div>

            <Row>
                <Col xs={12} xl={12}>
                    <Card border="light" className="bg-white shadow-sm mb-4">
                        <Card.Body>
                            <h5 className="mb-4">Register Here</h5>
                            <Form>
                                <Row>
                                    <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Email Id</Form.Label>
                                            <Form.Control type="email" isInvalid={(errors && errors.email) && isValid(errors.email)} placeholder="Enter your Email Id" name='email' value={email} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.email}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col md={6} className="mb-3">
                                    <Form.Group id="firstName">
                                            <Form.Label>Password</Form.Label>
                                            <Form.Control type="password" isInvalid={(errors && errors.password) && isValid(errors.password)} placeholder="Create your Password" name='password' value={password} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.password}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <div className="mt-3">
                                    <Button variant="primary" type="button" onClick={handleSubmit}>Sign In</Button>
                                </div>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};
