import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { Col, Row, Button, Card, Form } from '@themesberg/react-bootstrap';

// import packages
import isEmpty from 'is-empty';


// import actions
import { addCarousel } from '../../actions/carouselActions';

// import lib
import toastAlert from '../../lib/toaster';

const initialFormValue = {
    'offername':'',
    'name': '',
    'image':''
}
export default () => {

    // hooks
    const navigate = useHistory();


    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState({});
    const { offername, name, image} = formValue;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValue({ ...formValue, ... { [name]: value } })
    }

    const handleFileChange = (e) => {
        const { name, files } = e.target;
        setFormValue({ ...formValue, ... { [name]: files[0] } })
    }

    const handleSubmit = async () => {
        try {
            let formData = new FormData();
            formData.append('offername', offername)
            formData.append('name', name)
            formData.append('image', image);
            let { status, message, errors } = await addCarousel(formData);

            if (status === true) {
                toastAlert('success', message)
                setFormValue(initialFormValue)
                setErrors({});
                navigate.push('/carousel-list')
            } else if (status === false) {
                if (errors) {
                    setErrors(errors);
                }

                if (message) {
                    toastAlert('error', message)
                }
            }
        } catch (err) { }
    }

    const isValid = (errName) => {
        return !isEmpty(errName);
    }

    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
            </div>

            <Row>
                <Col xs={12} xl={12}>
                    <Card border="light" className="bg-white shadow-sm mb-4">
                        <Card.Body>
                            <h5 className="mb-4">Add Carousel</h5>
                            <Form>
                            <Row>
                                    <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Offer Name</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.offername) && isValid(errors.offername)} placeholder="Enter your offer name" name='offername' value={offername} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.offername}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col md={6} className="mb-3">
                                        <Form.Group id="firstName">
                                            <Form.Label>Name</Form.Label>
                                            <Form.Control type="text" isInvalid={(errors && errors.name) && isValid(errors.name)} placeholder="Enter your name" name='name' value={name} onChange={handleChange} />
                                            <Form.Control.Feedback type="invalid">{errors && errors.name}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col md={6} className="mb-3">
                                        <Form.Group id="image">
                                            <Form.Label>Image</Form.Label>
                                            <Form.Control type="file" isInvalid={(errors && errors.image) && isValid(errors.image)} placeholder="Select Product Image" name='image' onChange={handleFileChange} />
                                            {image && <img src={URL.createObjectURL(image)} style={{ 'width': '70px' }} />}
                                            <Form.Control.Feedback type="invalid">{errors && errors.image}</Form.Control.Feedback>
                                        </Form.Group>
                                    </Col>
                                </Row>
                                <div className="mt-3">
                                    <Button variant="primary" type="button" onClick={handleSubmit}>Save</Button>
                                </div>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};
