import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Card, Table } from '@themesberg/react-bootstrap';



// import actions
import { getProductView } from '../../actions/euserAction';


export default () => {

    const { orderId } = useParams();

    const [data, setData] = useState([]);

    const getData = async () => {
        try {

            let { status, result } = await getProductView(orderId)

            if (status === true) {
                setData(result)
            }

        } catch (err) {

        }
    }

    useEffect(() => {
        getData()
    }, [])

    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
                <div className="d-block mb-4 mb-md-0">
                    <h4>Cart List</h4>
                </div>
            </div>

            <Card border="light" className="table-wrapper table-responsive shadow-sm">
                <Card.Body className="pt-0">
                    <Table hover className="user-table align-items-center">
                        <thead>
                            <tr>
                                <th className="border-bottom">Name</th>
                                <th className="border-bottom">Image</th>
                                <th className="border-bottom">Price</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                data && data.length > 0 && data.map((item) => {
                                    return (
                                        <tr>
                                              <td>
                                                <span className="fw-normal">
                                                    {item.productDoc.name}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                <img src={item.productDoc.image} alt={item.productDoc.name} style={{ 'width': '70px' }} />
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.productDoc.price}
                                                </span>
                                            </td>
                                        </tr>
                                    );
                                })
                            }
                        </tbody>
                    </Table>
                    <Card.Footer className="px-3 border-0 d-lg-flex align-items-center justify-content-between">
                    </Card.Footer>
                </Card.Body>
            </Card>
        </>
    );
};
