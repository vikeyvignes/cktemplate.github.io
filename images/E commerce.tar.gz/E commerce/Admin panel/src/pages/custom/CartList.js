import React, { useEffect, useState } from "react";
import { Card, Table } from '@themesberg/react-bootstrap';



// import actions
import { getCart } from '../../actions/euserAction';


export default () => {

    const [data, setData] = useState([]);
    const [IMAGE_URL, SET_IMAGE_URL] = useState('');

    const getData = async () => {
        try {

            let { status, result, imageUrl } = await getCart()

            if (status === true) {
                setData(result)
                SET_IMAGE_URL(imageUrl)
            }

        } catch (err) {

        }
    }

    useEffect(() => {
        getData()
    }, [])




    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
                <div className="d-block mb-4 mb-md-0">
                    <h4>Cart List</h4>
                </div>
            </div>

            <Card border="light" className="table-wrapper table-responsive shadow-sm">
                <Card.Body className="pt-0">
                    <Table hover className="user-table align-items-center">
                        <thead>
                            <tr>
                                <th className="border-bottom">User EmailId</th>
                                <th className="border-bottom">Product Name</th>
                                <th className="border-bottom">Image</th>
                                <th className="border-bottom">Price</th>
                                <th className="border-bottom">Quantity</th>
                                <th className="border-bottom">Total</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                data && data.length > 0 && data.map((item) => {
                                    return (
                                        <tr>
                                              <td>
                                                <span className="fw-normal">
                                                    {item.userId.email}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.productId.name}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    <a href={`${IMAGE_URL}/${item.productId.image}`} target="_blank" ><img src={`${IMAGE_URL}/${item.productId.image}`} style={{ 'width': '70px' }} /></a>
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.productId.price}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.quantity}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.total}
                                                </span>
                                            </td>
                                        </tr>
                                    );
                                })
                            }
                        </tbody>
                    </Table>
                    <Card.Footer className="px-3 border-0 d-lg-flex align-items-center justify-content-between">
                    </Card.Footer>
                </Card.Body>
            </Card>
        </>
    );
};
