import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Card, Table, Button, Badge } from '@themesberg/react-bootstrap';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashAlt, faPencilAlt,faEnvelope } from "@fortawesome/free-solid-svg-icons";


// import actions
import { getOrderlist, orderUpdate } from '../../actions/euserAction';


//import lib
import toastAlert from '../../lib/toaster'

export default () => {

    const navigate = useHistory();
    const [data, setData] = useState([]);

    const handleChangeStatus = async (id) => {
        try {
            let data = { id }
            let { status, message } = await orderUpdate(data)
            if (status === true) {
                toastAlert('success', message)
                getData()
            }

            if (status === false) {
                toastAlert('success', message)
            }
        } catch (err) {

        }
    }

    const getData = async () => {
        try {

            let { status, result } = await getOrderlist()

            if (status === true) {
                setData(result)
            }

        } catch (err) {

        }
    }

    useEffect(() => {
        getData()
    }, [])

    const viewproducts = (id) => {
        navigate.push('/product-status/' + id)
    }


    return (
        <>
            <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
                <div className="d-block mb-4 mb-md-0">
                    <h4>Order List</h4>
                </div>
            </div>

            <Card border="light" className="table-wrapper table-responsive shadow-sm">
                <Card.Body className="pt-0">
                    <Table hover className="user-table align-items-center">
                        <thead>
                            <tr>
                                <th className="border-bottom">User EmailId</th>
                                <th className="border-bottom">User PhoneNo</th>
                                <th className="border-bottom">Total price</th>
                                <th className="border-bottom">Payment type</th>
                                <th className="border-bottom">Status</th>
                                <th className="border-bottom">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                data && data.length > 0 && data.map((item) => {
                                    return (
                                        <tr>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.userId.email}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.userId.phoneNo}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.total}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="fw-normal">
                                                    {item.paymentType}
                                                </span>
                                            </td>
                                            <td>
                                                <Badge
                                                    pill={true}
                                                    bg="success"
                                                    className="me-1"
                                                    onClick={() => handleChangeStatus(item._id)}>
                                                    {item.status}
                                                </Badge>
                                            </td>
                                            <td>
                                                <Button
                                                    variant="secondary"
                                                    className="m-1"
                                                    onClick={() => viewproducts(item._id)}>
                                                    <FontAwesomeIcon icon={faPencilAlt} className="me-2" />
                                                    ViewProduct
                                                </Button>
                                            </td>
                                        </tr>
                                    );
                                })
                            }
                        </tbody>
                    </Table>
                    <Card.Footer className="px-3 border-0 d-lg-flex align-items-center justify-content-between">
                    </Card.Footer>
                </Card.Body>
            </Card >
        </>
    );
};
