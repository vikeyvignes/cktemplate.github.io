// import config
import axios from "../config/axios";

export const getContact = async (reqData) => {
    try {
        let respData = await axios({

            'url': '/contact-list',
            'method': 'get',
            'params' : reqData
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,

        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}

export const getCart = async () => {
    try {
        let respData = await axios({

            'url': '/cart-list',
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}

export const login = async (data) => {

    try {
        let respData = await axios({
            'url': '/admin-login',
            'method': 'post',
            data
        })
        return {
            'status': respData.data.status,
            'message': respData.data.message,
            'token': respData.data.token
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors
        }
    }
}

export const getOrderlist = async () => {
    try {
        let respData = await axios({

            'url': '/order-list',
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}

export const orderUpdate = async (data) => {
    try {
        let respData = await axios({
            'url': '/order-update',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
        }

    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
} 

export const UserMessage = async (data) => {

    try {
        let respData = await axios({
            'url': '/user-message' ,
            'method': 'post',
            data
        })
        return {
            'status': respData.data.status,
            'result': respData.data.result,
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'result': err.response.data.result,
            'errors': err.response.data.errors
        }
    }
}

export const getProductView = async (orderId) => {

    try {
        let respData = await axios({
            'url': '/get-product-view/' + orderId,
            'method': 'get'
        })
        return {
            'status': respData.data.status,
            'result': respData.data.result,
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'result': err.response.data.result,
            'errors': err.response.data.errors
        }
    }
}