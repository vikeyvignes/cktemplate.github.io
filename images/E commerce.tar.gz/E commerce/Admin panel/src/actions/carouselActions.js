// import config
import axios from "../config/axios";




export const addCarousel = async (formData) => {
    try {
        let respData = await axios({
            'url': '/carousel-add',
            'method': 'post',
            'data': formData
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
            
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}
export const getCarousel = async () => {
    try {
        let respData = await axios({

            'url': '/carousel-list',
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}
export const editCarousel = async (data) => {

    try {
        let respData = await axios({
            'url': '/carousel-update',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}
export const deleteCarousel = async (id) => {

    try {
        let respData = await axios({
            'url': '/carousel-delete/' + id,
            'method': 'get'
        })
        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
        }
    }

}
export const getSingleCarousel = async (id) => {
    try {
        let respData = await axios({

            'url': '/get-singlecarousel/' + id,
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}