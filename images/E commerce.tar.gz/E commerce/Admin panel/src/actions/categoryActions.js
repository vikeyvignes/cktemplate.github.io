// import config
import axios from "../config/axios";




export const addCategory = async (formData) => {
    try {
        let respData = await axios({
            'url': '/category-add',
            'method': 'post',
            'data': formData
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
            
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}
export const getCategory = async () => {
    try {
        let respData = await axios({

            'url': '/category-list',
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}
export const editCategory = async (data) => {

    try {
        let respData = await axios({
            'url': '/category-update',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}
export const deleteCategory = async (id) => {

    try {
        let respData = await axios({
            'url': '/category-delete/' + id,
            'method': 'get'
        })
        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
        }
    }

}
export const getSingleCategory = async (id) => {
    try {
        let respData = await axios({

            'url': '/get-singlecategory/' + id,
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}

export const addQuiz = async (data) => {
    try {
        let respData = await axios({
            'url': '/create-quiz',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
            
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}