// import config
import axios from "../config/axios";


export const addProduct = async (formData) => {
    try {
        let respData = await axios({
            'url': '/product-add',
            'method': 'post',
            'data': formData
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}

export const getProduct = async () => {
    try {
        let respData = await axios({

            'url': '/product-list',
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}


export const editProduct = async (data) => {

    try {
        let respData = await axios({
            'url': '/product-update',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors,
        }
    }
}
export const deleteProduct = async (id) => {

    try {
        let respData = await axios({
            'url': '/product-delete/' + id,
            'method': 'get'
        })
        return {
            'status': respData.data.status,
            'message': respData.data.message
        }
    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
        }
    }

}
export const getSingleProduct = async (id) => {
    try {
        let respData = await axios({

            'url': '/get-singleproduct/' + id,
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}

export const statusUpdate = async (data) => {
    try {
        let respData = await axios({
            'url': '/status-update',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
        }

    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
} 
