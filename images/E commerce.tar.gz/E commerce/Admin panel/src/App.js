import React, { useState, useEffect } from 'react';
import { Route, Switch, Redirect } from "react-router-dom";

import { Routes } from "./routes";


// custom pages
import TestForm from "./pages/custom/Form";
import Testtable from "./pages/custom/test-table";
import ProductAdd from "./pages/custom/Product-add";
import ProductList from "./pages/custom/Product-list";
import EditProduct from "./pages/custom/Edit-products";
import CategoryAdd from "./pages/custom/CatergoryAdd";
import CategoryList from "./pages/custom/CatergoryList";
import EditCategory from "./pages/custom/EditCategory";
import CarouselAdd from "./pages/custom/CarouselAdd";
import CarouselList from "./pages/custom/CarouselList";
import EditCarousel from './pages/custom/Edit-carousel';
import ContactList from './pages/custom/ContactList';
import CartList from './pages/custom/CartList';
import Login from './pages/custom/Login';
import OrderList from './pages/custom/OrderList';
import OrderProductStatus from './pages/custom/OrderProductStatus';
import UserMessage from './pages/custom/UserMessage';
import QuizAdd from './pages/custom/QuizAdd';


// pages
import Presentation from "./pages/Presentation";
import Upgrade from "./pages/Upgrade";
import DashboardOverview from "./pages/dashboard/DashboardOverview";
import Transactions from "./pages/Transactions";
import Settings from "./pages/Settings";
import BootstrapTables from "./pages/tables/BootstrapTables";
import Signin from "./pages/examples/Signin";
import Signup from "./pages/examples/Signup";
import ForgotPassword from "./pages/examples/ForgotPassword";
import ResetPassword from "./pages/examples/ResetPassword";
import Lock from "./pages/examples/Lock";
import NotFoundPage from "./pages/examples/NotFound";
import ServerError from "./pages/examples/ServerError";

// documentation pages
import DocsOverview from "./pages/documentation/DocsOverview";
import DocsDownload from "./pages/documentation/DocsDownload";
import DocsQuickStart from "./pages/documentation/DocsQuickStart";
import DocsLicense from "./pages/documentation/DocsLicense";
import DocsFolderStructure from "./pages/documentation/DocsFolderStructure";
import DocsBuild from "./pages/documentation/DocsBuild";
import DocsChangelog from "./pages/documentation/DocsChangelog";

// components
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Preloader from "./components/Preloader";

import Accordion from "./pages/components/Accordion";
import Alerts from "./pages/components/Alerts";
import Badges from "./pages/components/Badges";
import Breadcrumbs from "./pages/components/Breadcrumbs";
import Buttons from "./pages/components/Buttons";
import Forms from "./pages/components/Forms";
import Modals from "./pages/components/Modals";
import Navs from "./pages/components/Navs";
import Navbars from "./pages/components/Navbars";
import Pagination from "./pages/components/Pagination";
import Popovers from "./pages/components/Popovers";
import Progress from "./pages/components/Progress";
import Tables from "./pages/components/Tables";
import Tabs from "./pages/components/Tabs";
import Tooltips from "./pages/components/Tooltips";
import Toasts from "./pages/components/Toasts";




const RouteWithLoader = ({ component: Component, ...rest }) => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <Route {...rest} render={props => ( <> <Preloader show={loaded ? false : true} /> <Component {...props} /> </> ) } />
  );
};

const RouteWithSidebar = ({ component: Component, ...rest }) => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const localStorageIsSettingsVisible = () => {
    return localStorage.getItem('settingsVisible') === 'false' ? false : true
  }

  const [showSettings, setShowSettings] = useState(localStorageIsSettingsVisible);

  const toggleSettings = () => {
    setShowSettings(!showSettings);
    localStorage.setItem('settingsVisible', !showSettings);
  }

  return (
    <Route {...rest} render={props => (
      <>
        <Preloader show={loaded ? false : true} />
        <Sidebar />

        <main className="content">
          <Navbar />
          <Component {...props} />
          <Footer toggleSettings={toggleSettings} showSettings={showSettings} />
        </main>
      </>
    )}
    />
  );
};

export default () => (
  <Switch>
    <RouteWithLoader exact path={Routes.Presentation.path} component={Presentation} />
    <RouteWithLoader exact path={Routes.Signin.path} component={Signin} />
    <RouteWithLoader exact path={Routes.Signup.path} component={Signup} />
    <RouteWithLoader exact path={Routes.ForgotPassword.path} component={ForgotPassword} />
    <RouteWithLoader exact path={Routes.ResetPassword.path} component={ResetPassword} />
    <RouteWithLoader exact path={Routes.Lock.path} component={Lock} />
    <RouteWithLoader exact path={Routes.NotFound.path} component={NotFoundPage} />
    <RouteWithLoader exact path={Routes.ServerError.path} component={ServerError} />

    {/* pages */}
    <RouteWithSidebar exact path={Routes.DashboardOverview.path} component={DashboardOverview} />
    <RouteWithSidebar exact path={Routes.Upgrade.path} component={Upgrade} />
    <RouteWithSidebar exact path={Routes.Transactions.path} component={Transactions} />
    <RouteWithSidebar exact path={Routes.Testtable.path} component={Testtable} />
    <RouteWithSidebar exact path={Routes.ProductAdd.path} component={ProductAdd} />
    <RouteWithSidebar exact path={Routes.ProductList.path} component={ProductList} />
    <RouteWithSidebar exact path={Routes.EditProduct.path} component={EditProduct} />
    <RouteWithSidebar exact path={Routes.CategoryAdd.path} component={CategoryAdd} />
    <RouteWithSidebar exact path={Routes.CategoryList.path} component={CategoryList} />
    <RouteWithSidebar exact path={Routes.EditCategory.path} component={EditCategory} />
    <RouteWithSidebar exact path={Routes.CarouselAdd.path} component={ CarouselAdd} />
    <RouteWithSidebar exact path={Routes.CarouselList.path} component={ CarouselList} />
    <RouteWithSidebar exact path={Routes.EditCarousel.path} component={ EditCarousel} />
    <RouteWithSidebar exact path={Routes.EditCarousel.path} component={ EditCarousel} />
    <RouteWithSidebar exact path={Routes.ContactList.path} component={ ContactList} />
    <RouteWithSidebar exact path={Routes.CartList.path} component={ CartList} />
    <RouteWithSidebar exact path={Routes.Login.path} component={ Login} />
    <RouteWithSidebar exact path={Routes.OrderList.path} component={ OrderList} />
    <RouteWithSidebar exact path={Routes.OrderProductStatus.path} component={ OrderProductStatus} />
    <RouteWithSidebar exact path={Routes.UserMessage.path} component={ UserMessage } />
    <RouteWithSidebar exact path={Routes.QuizAdd.path} component={ QuizAdd } />
    <RouteWithSidebar exact path={Routes.Settings.path} component={Settings} />
    <RouteWithSidebar exact path={Routes.TestForm.path} component={TestForm} />
    <RouteWithSidebar exact path={Routes.BootstrapTables.path} component={BootstrapTables} />

    {/* components */}
    <RouteWithSidebar exact path={Routes.Accordions.path} component={Accordion} />
    <RouteWithSidebar exact path={Routes.Alerts.path} component={Alerts} />
    <RouteWithSidebar exact path={Routes.Badges.path} component={Badges} />
    <RouteWithSidebar exact path={Routes.Breadcrumbs.path} component={Breadcrumbs} />
    <RouteWithSidebar exact path={Routes.Buttons.path} component={Buttons} />
    <RouteWithSidebar exact path={Routes.Forms.path} component={Forms} />
    <RouteWithSidebar exact path={Routes.Modals.path} component={Modals} />
    <RouteWithSidebar exact path={Routes.Navs.path} component={Navs} />
    <RouteWithSidebar exact path={Routes.Navbars.path} component={Navbars} />
    <RouteWithSidebar exact path={Routes.Pagination.path} component={Pagination} />
    <RouteWithSidebar exact path={Routes.Popovers.path} component={Popovers} />
    <RouteWithSidebar exact path={Routes.Progress.path} component={Progress} />
    <RouteWithSidebar exact path={Routes.Tables.path} component={Tables} />
    <RouteWithSidebar exact path={Routes.Tabs.path} component={Tabs} />
    <RouteWithSidebar exact path={Routes.Tooltips.path} component={Tooltips} />
    <RouteWithSidebar exact path={Routes.Toasts.path} component={Toasts} />

    {/* documentation */}
    <RouteWithSidebar exact path={Routes.DocsOverview.path} component={DocsOverview} />
    <RouteWithSidebar exact path={Routes.DocsDownload.path} component={DocsDownload} />
    <RouteWithSidebar exact path={Routes.DocsQuickStart.path} component={DocsQuickStart} />
    <RouteWithSidebar exact path={Routes.DocsLicense.path} component={DocsLicense} />
    <RouteWithSidebar exact path={Routes.DocsFolderStructure.path} component={DocsFolderStructure} />
    <RouteWithSidebar exact path={Routes.DocsBuild.path} component={DocsBuild} />
    <RouteWithSidebar exact path={Routes.DocsChangelog.path} component={DocsChangelog} />

    <Redirect to={Routes.NotFound.path} />    
  </Switch>
);
