const isEmpty = require('is-empty');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Models
const User = require('../models/user');

// lib
const sendMail = require('../lib/emailGateway');

// config
const config = require('../config');




const createUser = async (req, res) => {
    let checkEmail = await User.findOne({ 'email': req.body.email }).lean();
    if (!isEmpty(checkEmail)) {
        return res.status(400).json({ 'status': false, 'errors': { 'email': 'Email already exist' } })
    }


    let checkPhone = await User.findOne({ 'phoneNo': req.body.phoneNo }, { 'phoneNo': 1 }).lean();
    if (!isEmpty(checkPhone)) {
        return res.status(400).json({ 'status': false, 'errors': { 'phoneNo': 'Phone No already exist' } })
    }

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.password, salt);

    let newDoc = new User({
        'name': req.body.name,
        'age': req.body.age,
        'email': req.body.email,
        'phoneNo': req.body.phoneNo,
        'password': hash,
    })

    await newDoc.save();
    sendMail({
        to: req.body.email,
        content: '<h1>Register Successfully!.</h1>'
    })
    // console.log(newDoc);
    return res.status(200).json({ 'status': true, 'message': "Register successfully" })
}

const userLogin = async (req, res) => {
    let login = await User.findOne({ 'email': req.body.email }).lean();
    if (isEmpty(login)) {
        return res.status(400).json({ 'status': false, 'errors': { 'email': 'email not found' } })
    }
    const comparePassword = await bcrypt.compare(req.body.password, login.password);
    if (!comparePassword) {
        return res.status(400).json({ 'status': false, 'errors': { 'password': 'Wrong password' } });
    }

    let payload = { name: login.name, _id: login._id }
    let token = jwtSign(payload)
    // console.log(token, '----token')
    return res.status(200).json({ 'status': true, 'message': "Login successfully", token })
}

const forgetPasswordctrl = async (req, res) => {
    let find = await User.findOne({ 'email': req.body.email }).lean();
    console.log(find);
    if (isEmpty(find)) {
        return res.status(400).json({ 'status': false, 'message': 'Invalid EmailId' })
    }

    sendMail({
        to: req.body.email,
        content: `<a target="_blank" href="http://localhost:3000/resetpassword/${find._id}">Click here</a>`
    })

    return res.status(200).json({ 'status': true, 'message': "Please Check your email" })
}

const updateUserctrl = async (req, res) => {
    let userData = await User.findOneAndUpdate({ _id: req.body.id }, { '$set': { name: req.body.name, age: req.body.age, phoneNo: req.body.phoneNo, email: req.body.email,profile: req.file.filename } }, { new: 'true' });
    console.log(userData);

    return res.status(200).json({ 'status': true, 'message': "Data Updated successfully" })
}

const getSingleUser = async (req, res) => {
    try {
        let userData = await User.findOne({ _id: req.params.userId }, { _id: 0, password: 0, __v: 0 }).lean();
        // if (isEmpty(userData)) {
        //     return res.status(400).json({ 'status': false })
        // }
        console.log(userData)
        userData.profile =`${config.IMAGE.USER_FILE_URL_PATH}/${userData.profile}`
        return res.status(200).json({ 'status': true, 'result': userData })
    } catch (err) {
        return res.status(500).json({ 'status': false })
    }
}

const findUserctrl = async (req, res) => {
    let filterCond = {};
    if (req.user.role === 'student') {
        filterCond = { _id: req.user._id }
    } else if (req.user.role === 'teacher') {
        filterCond = { 'role': 'student', 'teacherId' : req.user._id }
    }
    let finddata = await User.find(filterCond);
    // console.log(finddata);
    return res.status(200).json({ 'status': true, 'result': "Data found successfully", 'data': finddata ,'imageUrl' : config.PROFILE.USER_FILE_URL_PATH })
}
const deleteUserctrl = async (req, res) => {
    if (isEmpty(req.body.id)) {
        return res.status(400).json({ 'status': false, 'message': "_Id is empty" })
    }

    let deletedata = await User.deleteOne({ _id: req.body.id });
    if (deletedata && deletedata.deletedCount != 0) {
        return res.status(200).json({ 'status': true, 'message': "Data Deleted successfully" })
    }

    return res.status(200).json({ 'status': true, 'message': "Already Deleted" })

}

const changePasswordctrl = async (req, res) => {

    let checkUser = await User.findOne({ '_id': req.user._id }).lean();
    if (!checkUser) {
        return res.status(400).json({ 'status': false, 'message': 'Invalid User' });
    }

    const comparePassword = await bcrypt.compare(req.body.password, checkUser.password);
    if (!comparePassword) {
        return res.status(400).json({ 'status': false, 'errors': { 'password': 'Old password is Wrong.' } });
    }
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.newpassword, salt);
    const changepassword = await User.findOneAndUpdate({ _id: req.user._id }, { $set: { 'password': hash } });
    console.log(changepassword);
    return res.status(200).json({ 'status': true, 'message': "Password changed successfully" })
}


const resetPassword = async (req, res) => {

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.newpassword, salt);
    const resetpassword = await User.findOneAndUpdate({ _id: req.body._id }, { $set: { 'password': hash } });
    console.log(resetpassword);
    return res.status(200).json({ 'status': true, 'message': "Password changed successfully" })
}

const jwtSign = (payload) => {
    let token = jwt.sign(payload, config.SECRET_KEY);
    return token;
}

const jwtVerify = (token) => {
    try {
        token = token.replace('Bearer ', '');
        let decoded = jwt.verify(token, config.SECRET_KEY);
        if (decoded) {
            return {
                'status': true,
                decoded
            }
        }

    } catch (err) {
        return {
            'status': false
        }
    }
}

const exportFunc = {
    createUser,
    userLogin,
    forgetPasswordctrl,
    updateUserctrl,
    findUserctrl,
    deleteUserctrl,
    changePasswordctrl,
    resetPassword,
    getSingleUser,
    jwtVerify,
    jwtSign
}
module.exports = exportFunc;