const isEmpty = require('is-empty');

// config
const config = require('../config');

// Models
const Category = require('../models/category');




const createCategory = async (req, res) => {
    try {
        let newDoc = new Category({
            'name': req.body.name,
            'image': req.file.filename,
        })

        await newDoc.save();
        return res.status(200).json({ 'status': true, 'message': "Category add successfully" })

    } catch (err) {
        return res.status(500).json({ 'status': false, 'message': 'Error on server' })
    }
}

const deletecategoryCtrl = async (req, res) => {

    if (isEmpty(req.params.id)) {
        return res.status(400).json({ 'status': false, 'message': "_Id is empty" })
    }

    let deletedata = await Category.deleteOne({ _id: req.params.id });
    if (deletedata && deletedata.deletedCount != 0) {
        return res.status(200).json({ 'status': true, 'message': "Data Deleted successfully" })
    }

    return res.status(200).json({ 'status': true, 'message': "Already Deleted" })
}

const updatecategoryCtrl = async (req, res) => {
    try {

        let updateDoc = {
            name: req.body.name,
        }

        if (!isEmpty(req.file)) {
            updateDoc.image = req.file.filename
        }

        let userData = await Category.findOneAndUpdate({ _id: req.body.categoryId }, { '$set': updateDoc } , { new: 'true' });
        // console.log(userData, '.....user');

     
        return res.status(200).json({ 'status': true, 'message': "Data Updated successfully" })
    } catch (err) {
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}
const getCategory = async (req, res) => {
    try {
        let userData = await Category.find();
        return res.status(200).json({ 'status': true, 'result': userData,'imageUrl': config.IMAGE.CATEGORY_FILE_URL_PATH })
    } catch (err) {
        // console.log(err, '--err')
        return res.status(500).json({ 'status': false })
    }
}
const getSingleCategory = async (req, res) => {
    try {
        let userData = await Category.findOne({ _id: req.params.id }).lean();
        userData.image = `${config.IMAGE.CATEGORY_FILE_URL_PATH}/${userData.image}`
        return res.status(200).json({ 'status': true, 'result': userData })
    } catch (err) {
        return res.status(500).json({ 'status': false })
    }
}

const getCategoryOne = async (req, res) => {
    try {
        let userData = await Category.findOne({});
        return res.status(200).json({ 'status': true, 'result': userData })
    } catch (err) {
        // console.log(err, '--err')
        return res.status(500).json({ 'status': false })
    }
}

module.exports = { createCategory, deletecategoryCtrl, updatecategoryCtrl, getCategory ,getSingleCategory, getCategoryOne};