const isEmpty = require('is-empty');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Models
const Products = require('../models/product');
const Category = require('../models/category');
const Cart = require('../models/cart');
const Euser = require('../models/euser')
const OrderPlace = require('../models/orderPlace')

// config
const config = require('../config');


const createProduct = async (req, res) => {
    try {

        let checkCategory = await Category.findOne({ '_id': req.body.categoryId });
        if (isEmpty(checkCategory)) {
            return res.status(400).json({ 'status': false, 'errors': { 'categoryId': 'Category is not found' } })
        }
        let newDoc = new Products({
            'name': req.body.name,
            'price': req.body.price,
            'availableQty': req.body.availableQty,
            'categoryId': req.body.categoryId,
            'image': req.file.filename,
            'description': req.body.description,
        })

        await newDoc.save();
        return res.status(200).json({ 'status': true, 'message': "Products add successfully" })

    } catch (err) {
        return res.status(500).json({ 'status': false, 'message': 'Error on server' })
    }
}

const deleteproductCtrl = async (req, res) => {

    if (isEmpty(req.params.id)) {
        return res.status(400).json({ 'status': false, 'message': "_Id is empty" })
    }

    let deletedata = await Products.deleteOne({ _id: req.params.id });
    if (deletedata && deletedata.deletedCount != 0) {
        return res.status(200).json({ 'status': true, 'message': "Data Deleted successfully" })
    }

    return res.status(200).json({ 'status': true, 'message': "Already Deleted" })
}

const updateproductCtrl = async (req, res) => {
    try {

        let checkCategory = await Category.findOne({ '_id': req.body.categoryId });
        if (isEmpty(checkCategory)) {
            return res.status(400).json({ 'status': false, 'errors': { 'categoryId': 'Category is not found' } })
        }

        let updateDoc = {
            name: req.body.name,
            price: req.body.price,
            availableQty: req.body.availableQty,
            categoryId: req.body.categoryId,
            description: req.body.description,
        }

        if (!isEmpty(req.file)) {
            updateDoc.image = req.file.filename
        }

        let userData = await Products.findOneAndUpdate({ _id: req.body.id }, { '$set': updateDoc }, { new: 'true' });
        console.log(userData, '.....user');

        return res.status(200).json({ 'status': true, 'message': "Data Updated successfully" })
    } catch (err) {
        console.log(err, '---err')
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}

const getProducts = async (req, res) => {
    try {
        let project = {
            path: 'categoryId',
            select: { '_id': 0, 'name': 1 }
        }
        let userData = await Products.find().populate(project);
        // console.log(userData);
        return res.status(200).json({ 'status': true, 'result': userData, 'imageUrl': config.IMAGE.PRODUCT_FILE_URL_PATH })
    } catch (err) {
        return res.status(500).json({ 'status': false })
    }
}
const getSingleProduct = async (req, res) => {
    try {
        let userData = await Products.findOne({ _id: req.params.id }).lean();
        // console.log(userData ,'userdaataa')
        userData.image = `${config.IMAGE.PRODUCT_FILE_URL_PATH}/${userData.image}`
        return res.status(200).json({ 'status': true, 'result': userData })
    } catch (err) {
        return res.status(500).json({ 'status': false })
    }
}
const statusUpdate = async (req, res) => {

    try {

        if (isEmpty(req.body.id)) {
            return res.status(400).json({ 'status': false, 'message': 'Id is required' })
        }

        let findDoc = await Products.findOne({ "_id": req.body.id }).lean();

        if (isEmpty(findDoc)) {
            return res.status(400).json({ 'status': false, 'message': 'Invalid Id' })
        }

        let newStatus = findDoc.status == 'active' ? 'deactive' : 'active';

        let statusChange = await Products.updateOne({ "_id": req.body.id }, { '$set': { status: newStatus } })
        // console.log(statusChange)
        return res.status(200).json({ 'status': true, 'message': `status ${newStatus} successfully` })
    } catch (err) {
        console.log(err, '---err')
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}

const getProductView = async (req, res) => {

    try {

        if (isEmpty(req.params.categoryId)) {
            return res.status(400).json({ 'status': false, 'message': 'Id is required' })
        }

        let findDoc = await Products.find({ "categoryId": req.params.categoryId, 'status': 'active' }).lean();
        


        return res.status(200).json({ 'status': true, 'result': findDoc, 'imageUrl': config.IMAGE.PRODUCT_FILE_URL_PATH,})
    } catch (err) {
        console.log(err, '---err')
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}

const getProductDetail = async (req, res) => {
    try {
        let userData = await Products.findOne({ _id: req.params.id }).lean();
        // console.log(userData ,'userdaataa')

        return res.status(200).json({ 'status': true, 'result': userData, 'imageUrl': config.IMAGE.PRODUCT_FILE_URL_PATH })
    } catch (err) {
        return res.status(500).json({ 'status': false })
    }
}


const createCart = async (req, res) => {

    try {
        //  console.log(req.body, '---req.body')
        let checkProduct = await Products.findOne({ '_id': req.body.productId }).lean();
        if (!checkProduct) {
            return res.status(400).json({ 'status': false, 'message': 'Invalid Product Id' })
        }
  
        let total = checkProduct.price * req.body.quantity;
        let checkId = await Cart.findOne({ 'productId': req.body.productId }).lean();
        // console.log(checkId, '----checkId')
        if (!checkId) {
            let newDoc = new Cart({
                'total': total,
                'quantity': req.body.quantity,
                'productId': req.body.productId,
                'userId': req.user._id
            })
            await newDoc.save();
            return res.status(200).json({ 'status': true, 'message': "Your product add in cart successfully" })

        }
        else if (checkId) {
          
            let data = await Cart.findOneAndUpdate(
                { 'productId': req.body.productId },
                { '$set': { 'quantity': req.body.quantity, 'total': total } },
                { 'new' : true }
            )
            
        }
        return res.status(200).json({ 'status': true, 'message': "Your product update in cart successfully" })
    } catch (err) {
        return res.status(500).json({ 'status': false, 'message': 'Error on server' })
    }

}

const getCartProducts = async (req, res) => {
    try {
        let cartView = {
            path: 'productId',
            select: { 'name': 1, 'image': 1, 'price': 1 }
        }
        let userData = await Cart.find({ "userId" : req.user._id }).populate(cartView);
        console.log(userData , 'userdataaaaa');
        let total = 0;
        for(let item of userData) {
          total = parseFloat(total) + parseFloat(item.total)
        }

        return res.status(200).json({ 'status': true, 'result': userData, 'total' : total, 'imageUrl': config.IMAGE.PRODUCT_FILE_URL_PATH })
    } catch (err) {
        console.log(err)
        return res.status(500).json({ 'status': false })
    }

}

const deletecartCtrl = async (req, res) => {

    if (isEmpty(req.params.id)) {
        return res.status(400).json({ 'status': false, 'message': "_Id is empty" })
    }

    let deletedata = await Cart.deleteOne({ _id: req.params.id });
    if (deletedata && deletedata.deletedCount != 0) {
        return res.status(200).json({ 'status': true, 'message': "Products removed in cart successfully" })
    }

    return res.status(200).json({ 'status': true, 'message': "Already Deleted" })
}


const checkOut = async (req,res) => {    

    let cartDoc = await Cart.find({ userId : req.user._id }, { 'quantity' : 1, 'productId' : 1, 'total' : 1 }).populate('productId'); 
    

    let total = 0, productIds = [];

    for(let item of cartDoc){
        productIds.push({
             '_id' : item.productId._id,
             'price' : item.productId.price,
             'quantity' : item.quantity,
             'total' : item.quantity * item.productId.price,
             'status' : 'new'
        })
        total = total + item.total
    }

    console.log(productIds, '----productIds')

    let newDoc = new OrderPlace({
        productIds : productIds,
        userId : req.user._id,
        paymentType : req.body.paymentType,
        total : total
    })

    await newDoc.save()
    await Cart.deleteMany({  userId : req.user._id });
    return res.status(200).json({ 'status': true, 'message': "Please confirm your payment" })

}

module.exports = {
    createProduct,
    deleteproductCtrl,
    updateproductCtrl,
    getProducts,
    getSingleProduct,
    statusUpdate,
    getProductView,
    getProductDetail,
    createCart,
    getCartProducts,
    deletecartCtrl,
    checkOut
}