const isEmpty = require('is-empty');

// config
const config = require('../config');

// Models
const Carousel = require('../models/carousel');



const createCarousel = async (req, res) => {
    try {
        let newDoc = new Carousel({
            'offername': req.body.offername,
            'name': req.body.name,
            'image': req.file.filename,
        })

        await newDoc.save();
        return res.status(200).json({ 'status': true, 'message': "Carousel add successfully" })

    } catch (err) {
        return res.status(500).json({ 'status': false, 'message': 'Error on server' })
    }
}

const deletecarouselCtrl = async (req, res) => {

    if (isEmpty(req.params.id)) {
        return res.status(400).json({ 'status': false, 'message': "_Id is empty" })
    }

    let deletedata = await Carousel.deleteOne({ _id: req.params.id });
    if (deletedata && deletedata.deletedCount != 0) {
        return res.status(200).json({ 'status': true, 'message': "Data Deleted successfully" })
    }

    return res.status(200).json({ 'status': true, 'message': "Already Deleted" })
}

const updatecarouselCtrl = async (req, res) => {
    try {

        let updateDoc = {
            offername: req.body.offername,
            name: req.body.name,
        }

        if (!isEmpty(req.file)) {
            updateDoc.image = req.file.filename
        }

        let userData = await Carousel.findOneAndUpdate({ _id: req.body.carouselId }, { '$set': updateDoc } , { new: 'true' });
        console.log(userData, '.....user');

     
        return res.status(200).json({ 'status': true, 'message': "Data Updated successfully" })
    } catch (err) {
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}
const getCarousel = async (req, res) => {
    try {
        let userData = await Carousel.find();
        // console.log(userData);
        return res.status(200).json({ 'status': true, 'result': userData,'imageUrl': config.IMAGE.CAROUSEL_FILE_URL_PATH })
    } catch (err) {
        // console.log(err, '--err')
        return res.status(500).json({ 'status': false })
    }
}
const getSingleCarousel = async (req, res) => {
    try {
        let userData = await Carousel.findOne({ _id: req.params.id }).lean();
        userData.image = `${config.IMAGE.CAROUSEL_FILE_URL_PATH}/${userData.image}`
        return res.status(200).json({ 'status': true, 'result': userData })
    } catch (err) {
        return res.status(500).json({ 'status': false })
    }
}

module.exports = { createCarousel, deletecarouselCtrl, updatecarouselCtrl, getCarousel ,getSingleCarousel};