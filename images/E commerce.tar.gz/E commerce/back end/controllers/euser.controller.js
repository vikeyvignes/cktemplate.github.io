const isEmpty = require('is-empty');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const cron = require('node-cron');

//models
const Euser = require('../models/euser');
const Contact = require('../models/contact');
const Cart = require('../models/cart');
const Product = require('../models/product');
const Admin = require('../models/admin');
const OrderPlace = require('../models/orderPlace');
const Quiz = require('../models/quiz')

// //lib
const sendMail = require('../lib/emailGateway');
const arrayDoc = require('../lib/arrayDoc');


//config
const config = require('../config/index');
const { jwtSign, jwtVerify } = require('./user.controller');


const ObjectId = mongoose.Types.ObjectId;

const createEUser = async (req, res) => {
    let checkEmail = await Euser.findOne({ 'email': req.body.email }).lean()
    if (!isEmpty(checkEmail)) {
        return res.status(400).json({ 'status': false, 'errors': { 'email': 'Email already Exist' } })
    }
    let checkPhoneNo = await Euser.findOne({ 'phoneNo': req.body.phoneNo }).lean()
    if (!isEmpty(checkPhoneNo)) {
        return res.status(400).json({ 'status': false, 'errors': { 'phoneNo': 'PhoneNo already Exist' } })
    }

    let salt = bcrypt.genSaltSync(10);
    let hash = bcrypt.hashSync(req.body.password, salt);

    let newUser = new Euser({
        'email': req.body.email,
        'phoneNo': req.body.phoneNo,
        'password': hash
    })

    await newUser.save();

    sendMail({
        'to': req.body.email,
        'content': '<h1>Registered successfully..!</h1>'
    })

    return res.status(200).json({ 'status': true, 'message': 'Registered successfully' })

}

const euserLogin = async (req, res) => {
    try {

        let checkArr = [{ 'email': req.body.email }];

        // 
        if (!isNaN(req.body.email)) {
            checkArr.push({ 'phoneNo': req.body.email })
        }

        let login = await Euser.findOne({ '$or': checkArr }).lean()

        if (isEmpty(login)) {
            return res.status(400).json({ 'status': false, 'errors': { 'email': '   Ivalid user details' } })
        }

        let comparePassword = await bcrypt.compare(req.body.password, login.password)
        if (comparePassword == false) {
            return res.status(400).json({ 'status': false, 'errors': { 'password': 'Invalid Password' } })
        }

        let payload = { _id: login._id }
        let token = jwtSign(payload)

        return res.status(200).json({ 'status': true, 'message': 'Login Successfully', token })
    } catch (err) {
        return res.status(400).json({ 'status': false, 'errors': { 'email': 'Invalid Credentials' } })
    }
}

const adminLogin = async (req, res) => {
    try {

        let checkArr = [{ 'email': req.body.email }];

        // 
        if (!isNaN(req.body.email)) {
            checkArr.push({ 'phoneNo': req.body.email })
        }

        let login = await Admin.findOne({ '$or': checkArr }).lean()

        if (isEmpty(login)) {
            return res.status(400).json({ 'status': false, 'errors': { 'email': '   Ivalid user details' } })
        }

        let comparePassword = await bcrypt.compare(req.body.password, login.password)
        if (comparePassword == false) {
            return res.status(400).json({ 'status': false, 'errors': { 'password': 'Invalid Passoword' } })
        }

        let payload = { _id: login._id }
        let token = jwtSign(payload)

        return res.status(200).json({ 'status': true, 'message': 'Login Successfully', token })
    } catch (err) {
        return res.status(400).json({ 'status': false, 'errors': { 'email': 'Invalid Credentials' } })
    }
}

const forgetPassword = async (req, res) => {
    let find = await Euser.findOne({ 'email': req.body.email }).lean();

    if (isEmpty(find)) {
        return res.status(400).json({ 'status': false, 'message': 'Invalid EmailId' })
    }

    sendMail({
        to: req.body.email,
        content: `<a target="_blank" href="http://localhost:3000/resetpassword/${find._id}">Click here</a>`
    })

    return res.status(200).json({ 'status': true, 'message': "Please Check your email" })
}
const resetPassword = async (req, res) => {

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.newpassword, salt);
    const resetpassword = await Euser.findOneAndUpdate({ _id: req.body._id }, { $set: { 'password': hash } });
    console.log(resetpassword);
    return res.status(200).json({ 'status': true, 'message': "Password changed successfully" })
}

const createContact = async (req, res) => {


    let newUser = new Contact({
        'email': req.body.email,
        'name': req.body.name,
        'subject': req.body.subject,
        'message': req.body.message
    })

    await newUser.save();

    sendMail({
        'to': req.body.email,
        'content': '<h1>Your message received successfully..!</h1>'
    })

    return res.status(200).json({ 'status': true, 'result': 'Your message received successfully' })

}

const getContact = async (req, res) => {
    try {

        let limit = req.query.limit;
        let skip = req.query.limit * (req.query.page - 1)
        let search = req.query.search;
        let filter = {};
        if (!isEmpty(search)) {
            filter = { '$or': [{ 'name': new RegExp(search, 'i') }, { 'email': new RegExp(search, 'i') }, { 'message': new RegExp(search, 'i') }, { 'subject': new RegExp(search, 'i') }] }
        }

        console.log(filter, '----filter')
        let countDoc = await Contact.countDocuments({});
        let data = await Contact.find(filter).skip(skip).limit(limit);
        // console.log(data);
        return res.status(200).json({ 'status': true, 'result': { 'records': data, 'count': countDoc } })
    } catch (err) {
        console.log(err, '--err')
        return res.status(500).json({ 'status': false })
    }
}


const getCartProducts = async (req, res) => {
    try {
        let cartView = {
            path: 'productId',
            select: { 'name': 1, 'image': 1, 'price': 1 }
        }
        let userView = {
            path: 'userId',
            select: { 'email': 1 }
        }
        let userData = await Cart.find({}).populate(cartView).populate(userView);
        // console.log(userData, 'userdataaaaa');
        let total = 0;
        for (let item of userData) {
            total = parseFloat(total) + parseFloat(item.total)
        }

        return res.status(200).json({ 'status': true, 'result': userData, 'total': total, 'imageUrl': config.IMAGE.PRODUCT_FILE_URL_PATH })
    } catch (err) {
        console.log(err)
        return res.status(500).json({ 'status': false })
    }

}

const getOrderdetails = async (req, res) => {
    try {

        let userView = {
            path: 'userId',
            select: { 'email': 1, 'phoneNo': 1 }
        }
        let userData = await OrderPlace.find({}).populate(userView);


        return res.status(200).json({ 'status': true, 'result': userData })
    } catch (err) {
        console.log(err)
        return res.status(500).json({ 'status': false })
    }

}

const orderUpdate = async (req, res) => {

    try {

        if (isEmpty(req.body.id)) {
            return res.status(400).json({ 'status': false, 'message': 'Id is required' })
        }

        let findDoc = await OrderPlace.findOne({ "_id": req.body.id }).lean();
        if (isEmpty(findDoc)) {
            return res.status(400).json({ 'status': false, 'message': 'Invalid Id' })
        }

        let newStatus = 'new';
        if (findDoc.status == 'new') {
            newStatus = 'picked'
        } else if (findDoc.status == 'picked') {
            newStatus = 'delivered'
        } else if (findDoc.status == 'delivered') {
            newStatus = 'new'
        }


        let statusChange = await OrderPlace.updateOne({ "_id": req.body.id }, { '$set': { status: newStatus } })
        return res.status(200).json({ 'status': true, 'message': `status ${newStatus} successfully` })
    } catch (err) {
        console.log(err, '---err')
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}

const userMessage = async (req, res) => {

    try {


        let Communicate = await Contact.findOne({ _id: req.body.orderId });
        console.log(Communicate, '-----com')
        let email = Communicate.email
        sendMail({
            'to': email,
            'content': req.body.replymessage
        })
        await Contact.updateOne({ '_id': req.body.orderId }, { '$set': { 'replymessage': req.body.replymessage } });
        return res.status(200).json({ 'status': true, 'result': 'Reply message send successfully' })
    } catch (err) {
        console.log(err, '---err')
        return res.status(500).json({ 'status': false, 'result': 'error on server' })
    }
}

const getProductView = async (req, res) => {
    try {

        let data = await OrderPlace.aggregate([
            {
                '$match': { '_id': new ObjectId(req.params.orderId) }
            },
            {
                '$unwind': '$productIds'
            },
            {
                '$lookup': {
                    'from': 'products',
                    'localField': 'productIds._id',
                    'foreignField': '_id',
                    'as': 'productDoc'
                }
            },
            {
                '$unwind': '$productDoc'
            },
            {
                '$project': {
                    'paymentType': 1,
                    'userId': 1,
                    'status': 1,
                    'productDoc': {
                        'name': 1,
                        '_id': 1,
                        'price': 1,
                        'image': { '$concat': [`${config.IMAGE.PRODUCT_FILE_URL_PATH}/`, '$productDoc.image'] }
                    }
                }
            }
        ])
        // console.log(data,'---dataaa')
        return res.status(200).json({ 'status': true, 'result': data })
    } catch (err) {
        console.log(err, '---err')
        return res.status(500).json({ 'status': false, 'result': 'error on server' })
    }
}

// cron.schedule('1,2,3,4,5 * * * * * *', () => {
//     console.log('running every minute 1, 2, 3, 4, 5');
// });

// const test = async (startCount, endCount) => {
//    if(startCount === endCount) {
//       console.log('***** LOOPING STOP *****')
//       return false;
//    } 
//    console.log(startCount, '-----startCount')
//    const newDoc = await Contact.insertMany(arrayDoc);
//    console.log('**** DATA SAVED *****')
//    startCount = startCount + 1;
//    return await test(startCount, endCount)
// }
// recursive function
// test(0, 1000)

const quiz = async (req, res) => {

    let count = await Quiz.countDocuments({});
    let questionNo = count + 1;
    let newUser = new Quiz({
        'question': req.body.question,
        'correctanswer': req.body.correctanswer,
        'option1': req.body.option1,
        'option2': req.body.option2,
        'option3': req.body.option3,
        'option4': req.body.option4,
        'questionNo': questionNo
    })

    await newUser.save();
    return res.status(200).json({ 'status': true, 'message': 'quiz added successfully' })

}
const getQuiz = async (req, res) => {
    try {
        console.log(req.body, '---quizz')
        let quizData = await Quiz.findOne({ questionNo: Number(req.body._id) }).lean();
        // console.log(quizData, 'quizDataaa')
        return res.status(200).json({ 'status': true, 'result': quizData })
    } catch (err) {
        console.log(err, '--err')
        return res.status(500).json({ 'status': false, 'message': 'error on server' })
    }
}

const nextQuestion = async (req, res) => {
    try {
      const questionNumber = req.body.questionNo;
  
      // Check if the question number is valid (between 1 and 10)
      if (questionNumber < 1 || questionNumber > 10) {
        return res.status(400).json({ status: false, message: 'Invalid question number' });
      }
  
      const currentQuestion = await Quiz.findOne({ questionNo: questionNumber });
  
      // Check if the current question exists
      if (!currentQuestion) {
        return res.status(404).json({ status: false, message: 'Question not found' });
      }
  
      const selectedOption = req.body.selectedOption;
  
      if (!selectedOption) {
        return res.status(400).json({ status: false, message: 'Please select an option.' });
      }
  
      // Initialize cumulative score with the current question's totalMark
      let cumulative = currentQuestion.totalMark;
  
      if (selectedOption === currentQuestion.correctanswer) {
        cumulative += 1;
      }
  
      // Update the totalMark for the next question (if it's not the 10th question)
      if (questionNumber < 10) {
        await Quiz.updateOne({ questionNo: questionNumber + 1 }, { $inc: { totalMark: 1 } });
      }
  
      // If it's the 10th question, calculate the final cumulative score
      if (questionNumber === 10) {
        const finalScore = await Quiz.aggregate([
          { $group: { _id: null, totalScore: { $sum: '$totalMark' } } },
        ]);
  
        if (finalScore.length > 0) {
          cumulative = finalScore[0].totalScore;
        }
      }
  
      return res.status(200).json({ status: true, message: 'Successfully updated score', cumulativeScore: cumulative });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ status: false, message: 'An error occurred' });
    }
  };
  
const quizcomplete = async (req, res) => {
    try {
        const lastRecord = await Quiz.findOne({}).sort({ questionNo: -1 }).limit(1);
        // console.log(lastRecord, '--last')
        return res.status(200).json({ 'status': true, 'result': lastRecord })
    } catch {
        return res.status(500).json({ 'status': false, 'message': 'An error occurred' });
    }
}
const resetTotalMarks = async (req, res) => {
    try {
        await Quiz.updateMany({}, { '$set': { 'totalMark': 0 } });
        return res.status(200).json({ 'status': true, 'message': 'Come on Buddy letz try onemore time' });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ 'status': false, 'message': 'An error occurred' });
    }
};

module.exports = {
    createEUser,
    euserLogin,
    forgetPassword,
    resetPassword,
    createContact,
    getContact,
    getCartProducts,
    adminLogin,
    getOrderdetails,
    orderUpdate,
    userMessage,
    getProductView,
    quiz,
    getQuiz,
    nextQuestion,
    quizcomplete,
    resetTotalMarks
};