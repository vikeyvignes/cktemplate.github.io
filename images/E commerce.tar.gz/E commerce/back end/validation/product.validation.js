
const isEmpty = require('is-empty');
const mongoose = require('mongoose');




const createProductvalid = (req, res, next) => {

    let errors = {};

    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter product name';
    }

    if (isEmpty(req.body.price)) {
        errors.price = 'Please enter price';
    } else if (isNaN(req.body.price)) {
        errors.price = 'price only allowed numeric';
    } else if (req.body.price <= 0) {
        errors.price = 'Please enter a valid price';
    }

    if (isEmpty(req.body.availableQty)) {
        errors.availableQty = 'Please enter Available Quantity';
    } else if (isNaN(req.body.availableQty)) {
        errors.availableQty = 'Available Quantity only allowed numeric';
    } else if (req.body.availableQty <= 0) {
        errors.availableQty = 'Please enter a valid Available Quantity';
    }

    if (isEmpty(req.body.categoryId)) {
        errors.categoryId = 'Please select a category';
    } else if (!mongoose.isValidObjectId(req.body.categoryId)) {
        errors.categoryId = 'Invalid Category';
    }

    if (isEmpty(req.file)) {
        errors.image = 'No file is choosen Please select a file'
    } else {
        let mimeType = req.file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        if (!['jpeg', 'png', 'jpg'].includes(fileType)) {
            errors.image = 'Only upload a file jpeg, jpg, png allowds'
        }
    }

    if (isEmpty(req.body.description)) {
        errors.description = 'Please enter product description';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}

const updateProductvalid = (req, res, next) => {
    let errors = {};

    // console.log(req.body, '-----req.body')
    // console.log(req.file, '-----req.file')
    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter product-name';
    }

    if (isEmpty(req.body.id)) {
        errors.id = 'id is required.';
    } else if (!mongoose.isValidObjectId(req.body.id)) {
        errors.id = 'Invalid id';
    }

    if (isEmpty(req.body.categoryId)) {
        errors.categoryId = 'Please select a category';
    } else if (!mongoose.isValidObjectId(req.body.categoryId)) {
        errors.categoryId = 'Invalid Category';
    }

    if (isEmpty(req.body.price)) {
        errors.price = 'Please enter price';
    } else if (isNaN(req.body.price)) {
        errors.price = 'price only allowed numeric';
    } else if (req.body.price <= 0) {
        errors.price = 'Please enter a valid price';
    }

    if (isEmpty(req.body.availableQty)) {
        errors.availableQty = 'Please enter Product-Qty';
    }

    if (!isEmpty(req.file)) {
        let mimeType = req.file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        if (!['jpeg', 'png', 'jpg'].includes(fileType)) {
            errors.image = 'Only upload a file jpeg, jpg, png allowds'
        }
    }
    if (isEmpty(req.body.description)) {
        errors.description = 'Please enter product description';
    }
    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}

const createCartValid = (req, res, next) => {

    let errors = {};

    if (isEmpty(req.body.productId)) {
        errors.productId = 'productId is required';
    }

    if (isEmpty(req.body.quantity)) {
        errors.quantity = 'Please enter quantity';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }

    return next();
}


const createCheckoutValid = (req, res, next) => {

    let errors = {};

    if (isEmpty(req.body.paymentType)) {
        errors.paymentType = 'Please select any one paymentType';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }

    return next();
}

module.exports = { createProductvalid, updateProductvalid, createCartValid, createCheckoutValid}