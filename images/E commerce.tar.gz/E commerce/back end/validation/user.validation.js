const isEmpty = require('is-empty');

const registerValid = (req, res, next) => {
    let errors = {};
    let passwordRegax = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
    let emailRegax = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter name';
    }

    if (isEmpty(req.body.age)) {
        errors.age = 'Please enter age';
    } else if (isNaN(req.body.age)) {
        errors.age = 'age only allowed numeric';
    } else if (req.body.age > 100 || req.body.age <= 0) {
        errors.age = 'Please enter a valid age';
    }

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter email';
    } else if (!(emailRegax).test(req.body.email)) {
        errors.email = 'Please enter a valid email address';
    }

    if (isEmpty(req.body.phoneNo)) {
        errors.phoneNo = 'Please enter Phone Number';
    } else if (isNaN(req.body.phoneNo)) {
        errors.phoneNo = 'phone No only allowed numeric';
    } else if (req.body.phoneNo.toString().length != 10) {
        errors.phoneNo = 'Please enter a valid phone number';
    }

    if (isEmpty(req.body.password)) {
        errors.password = 'Please enter password';
    } else if (!passwordRegax.test(req.body.password)) {
        errors.password = 'Password should be atleast One Uppercase, Lowercase, numbers and special characters, Minimum 8 to Maxximum 16 letters alloewd only';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }

    return next()
};

const loginValid = (req, res, next) => {
    let errors = {};
    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your email'
    }
    if (isEmpty(req.body.password)) {
        errors.password = 'Please enter your password'
    }
    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }

    return next();
}

const forgetpasswordValid = (req, res, next) => {
    let errors = {};

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your email'
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'message': errors })
    }
    return next();
}

const updateUservalid = (req, res, next) => {
    let errors = {};
    let emailRegax = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter name';
    }

    if (isEmpty(req.body.age)) {
        errors.age = 'Please enter age';
    } else if (isNaN(req.body.age)) {
        errors.age = 'age only allowed numeric';
    } else if (req.body.age > 100 || req.body.age <= 0) {
        errors.age = 'Please enter a valid age';
    }

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter email';
    } else if (!(emailRegax).test(req.body.email)) {
        errors.email = 'Please enter a valid email address';
    }

    if (isEmpty(req.body.phoneNo)) {
        errors.phoneNo = 'Please enter Phone Number';
    } else if (isNaN(req.body.phoneNo)) {
        errors.phoneNo = 'phone No only allowed numeric';
    } else if (req.body.phoneNo.toString().length != 10) {
        errors.phoneNo = 'Please enter a valid phone number';
    }

    if (isEmpty(req.file)) {
        errors.image = 'No file is choosen Please select a file'
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}


const changepasswordValid = (req, res, next) => {
    let errors = {};
    let passwordRegex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
    console.log(req.body, '----req.body')
    if (isEmpty(req.body.password)) {
        errors.password = 'Please enter your password'
    } 

    if (isEmpty(req.body.newpassword)) {
        errors.newpassword = 'Please enter your  new password'
    } else if (!passwordRegex.test(req.body.newpassword)) {
        errors.newpassword = 'Password should be atleast One Uppercase, Lowercase, numbers and special characters, Minimum 8 to Maxximum 16 letters alloewd only';
    }

    if (isEmpty(req.body.confirmpassword)) {
        errors.confirmpassword = 'Please re-enter your new password'
    } else if (req.body.newpassword != req.body.confirmpassword) {
        errors.confirmpassword = 'Confirm Password Not Same';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}


const resetpasswordValid = (req, res, next) => {
    let errors = {};
    let passwordRegex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;

    if (isEmpty(req.body.newpassword)) {
        errors.newpassword = 'Please enter your  new password'
    } else if (!passwordRegex.test(req.body.newpassword)) {
        errors.newpassword = 'Password should be atleast One Uppercase, Lowercase, numbers and special characters, Minimum 8 to Maxximum 16 letters alloewd only';
    }

    if (isEmpty(req.body.confirmpassword)) {
        errors.confirmpassword = 'Please re-enter your new password'
    } else if (req.body.newpassword != req.body.confirmpassword) {
        errors.confirmpassword = 'Confirm Password Not Same';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}
module.exports = { registerValid, loginValid, forgetpasswordValid, updateUservalid, changepasswordValid,resetpasswordValid }