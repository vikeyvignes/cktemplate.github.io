const isEmpty = require('is-empty');
const mongoose = require('mongoose');




const CreatecategoryValid = (req, res, next) => {

    let errors = {};

    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter category name';
    }
    if (isEmpty(req.file)) {
        errors.image = 'No file is choosen Please select a file'
    } else {
        let mimeType =  req.file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        if(!['jpeg', 'png', 'jpg'].includes(fileType)){
            errors.image = 'Only upload a file jpeg, jpg, png allowds'
        }
    }
    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}
const updateCatergoryvalid = (req, res, next) => {
    let errors = {};

    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter category name';
    }
    if (!isEmpty(req.file)) {
        let mimeType =  req.file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        if(!['jpeg', 'png', 'jpg'].includes(fileType)){
            errors.image = 'Only upload a file jpeg, jpg, png allowds'
        }
    }
    
    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}
module.exports = {CreatecategoryValid, updateCatergoryvalid};