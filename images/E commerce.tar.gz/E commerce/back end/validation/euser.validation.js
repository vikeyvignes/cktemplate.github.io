const isEmpty = require('is-empty');
const mongoose = require('mongoose');


const createEuserValid = (req, res, next) => {

    let errors = {};
    let passwordRegax = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
    let emailRegax = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your email'
    } else if (!emailRegax.test(req.body.email)) {
        errors.email = 'Please enter a valid email address'
    }

    if (isEmpty(req.body.phoneNo)) {
        errors.phoneNo = 'Please enter your phoneNo'
    } else if (isNaN(req.body.phoneNo)) {
        errors.phoneNo = 'Phone number only allowed numeric'
    } else if (req.body.phoneNo.toString().length != 10) {
        errors.phoneNo = 'Phone number only 10 digit numbers'
    }

    if (isEmpty(req.body.password)) {
        errors.password = 'Please enter your password'
    } else if (!passwordRegax.test(req.body.password)) {
        errors.password = 'Password should be atleast One Uppercase, Lowercase, numbers and special characters, Minimum 8 to Maxximum 16 letters allowed only';
    }
    if (isEmpty(req.body.confirmpassword)) {
        errors.confirmpassword = 'Please re-enter your password '
    } else if (req.body.password != req.body.confirmpassword) {
        errors.confirmpassword = 'Password and Confirm password are not same'
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }

    return next();
}
const euserLoginValid = (req, res, next) => {

    let errors = {}

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your registered Eamil Id/phone Number'
    }

    if (isEmpty(req.body.password)) {
        errors.password = 'Please enter your Password'
    }
    if (!isEmpty(errors)) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }


    return next()
}
const adminLoginValid = (req, res, next) => {

    let errors = {}

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your registered Eamil Id/phone Number'
    }

    if (isEmpty(req.body.password)) {
        errors.password = 'Please enter your Password'
    }
    if (!isEmpty(errors)) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }


    return next()
}
const forgetpasswordValid = (req, res, next) => {
    let errors = {};

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your email'
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}

const resetpasswordValid = (req, res, next) => {
    let errors = {};
    let passwordRegex = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;

    if (isEmpty(req.body.newpassword)) {
        errors.newpassword = 'Please enter your  new password'
    } else if (!passwordRegex.test(req.body.newpassword)) {
        errors.newpassword = 'Password should be atleast One Uppercase, Lowercase, numbers and special characters, Minimum 8 to Maxximum 16 letters alloewd only';
    }

    if (isEmpty(req.body.confirmpassword)) {
        errors.confirmpassword = 'Please re-enter your new password'
    } else if (req.body.newpassword != req.body.confirmpassword) {
        errors.confirmpassword = 'Confirm Password Not Same';
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();
}

const createContactValid = (req, res, next) => {
    let errors = {};

    if (isEmpty(req.body.name)) {
        errors.name = 'Please enter your name'
    }

    if (isEmpty(req.body.email)) {
        errors.email = 'Please enter your email'
    }

    if (isEmpty(req.body.subject)) {
        errors.subject = 'Please enter your subject'
    }

    if (isEmpty(req.body.message)) {
        errors.message = 'Please enter your message'
    }

    if (isEmpty(errors) == false) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next();

}

const messageValid = (req, res, next) => {

    let errors = {}

    if (isEmpty(req.body.replymessage)) {
        errors.replymessage = 'Please enter your replymessage'
    }
    if (!isEmpty(errors)) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }


    return next()
}
const quizValid = (req, res, next) => {

    let errors = {}

    if (isEmpty(req.body.question)) {
        errors.question = 'Please enter question'
    }
    if (isEmpty(req.body.correctanswer)) {
        errors.correctanswer = 'Please enter correct answer'
    }
    if (isEmpty(req.body.correctanswer)) {
        errors.correctanswer = 'Please enter correct answer'
    }
    if (isEmpty(req.body.option1)) {
        errors.option1 = 'Please enter option1'
    }
    if (isEmpty(req.body.option2)) {
        errors.option2 = 'Please enter option2'
    }
    if (isEmpty(req.body.option3)) {
        errors.option3 = 'Please enter option3'
    }
    if (isEmpty(req.body.option4)) {
        errors.option4 = 'Please enter option4'
    }
    if (!isEmpty(errors)) {
        return res.status(400).json({ 'status': false, 'errors': errors })
    }
    return next()
}

module.exports = { createEuserValid, euserLoginValid, forgetpasswordValid, resetpasswordValid, createContactValid,adminLoginValid, messageValid, quizValid }