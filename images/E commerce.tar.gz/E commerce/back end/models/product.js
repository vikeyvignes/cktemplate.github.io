const mongoose = require('mongoose');
const { Schema } = mongoose;
const ObjectId = mongoose.Types.ObjectId;


const productSchema =  new Schema({
    'name':String,
    'price' : Number,
    'availableQty' : Number,
    'image' : String,
    'status' : {
        type : String,
        default : 'active'
    },
    'categoryId' : {
        type : ObjectId,
        ref : 'category'
    },
    'description':String
})

let productModel = mongoose.model('products', productSchema, 'products');


module.exports =  productModel;