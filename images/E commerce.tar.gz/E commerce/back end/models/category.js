const mongoose = require('mongoose');
const { Schema } = mongoose;


const categorySchema = new Schema({
    'name': String,
    'image' : String
})

let categoryModel = mongoose.model('category', categorySchema, 'category');


module.exports = categoryModel;