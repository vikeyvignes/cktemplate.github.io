const mongoose = require('mongoose');
const { Schema } = mongoose;
const ObjectId = mongoose.Types.ObjectId;


const cartSchema =  new Schema({

    'total' :Number,   
    'quantity' : Number,
    'productId' : {
        type : ObjectId,
        ref : 'products'
    },
    'userId' : {
        type : ObjectId,
        ref : 'euser'
    }
   
})

let cartModel = mongoose.model('cart', cartSchema, 'cart');


module.exports =  cartModel;