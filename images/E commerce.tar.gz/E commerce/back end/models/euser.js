const mongoose = require('mongoose');
const { Schema } = mongoose;


const euserSchema = new Schema ({

    'email' : String,
    'phoneNo' : Number,
    'password' : String
})

let euserModel = mongoose.model('euser', euserSchema, 'euser' )


module.exports = euserModel;


