const mongoose = require('mongoose');
const { Schema } = mongoose;


const adminSchema = new Schema ({

    'email' : String,
    'phoneNo' : Number,
    'password' : String
})

let adminModel = mongoose.model('admin', adminSchema, 'admin' )


module.exports = adminModel;