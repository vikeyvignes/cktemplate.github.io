const mongoose = require('mongoose');
const { Schema } = mongoose;


const quizSchema = new Schema ({

    'question' : String,
    'correctanswer' : String,
    'option1' : String,
    'option2' : String,
    'option3' : String,
    'option4' : String,
    'questionNo' :{
        'type' :Number,
        default:0
    },
    'totalMark' :{
        'type' :Number,
        default:0
    },

})

let quizModel = mongoose.model('quiz',quizSchema, 'quiz' )


module.exports =quizModel;