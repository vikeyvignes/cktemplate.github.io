const mongoose = require('mongoose');
const { Schema } = mongoose;
// const ObjectId = mongoose.Types.ObjectId;


const carouselSchema =  new Schema({
    'offername':String,
    'name':String,
    'image' : String,
})

let carouselModel = mongoose.model('carousel', carouselSchema, 'carousel');


module.exports =  carouselModel;