const mongoose = require('mongoose') ;
const {Schema} = mongoose;

const Contact = new Schema ({

    'name' : String,
    'email' :String,
    'subject' : String,
    'message' : String,
    'replymessage': [{ type: String }]
})

const ContactModel = mongoose.model('contact',Contact,'contact');

module.exports = ContactModel;