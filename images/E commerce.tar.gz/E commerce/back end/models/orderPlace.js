const mongoose = require('mongoose');
const { Schema } = mongoose;
const ObjectId = mongoose.Types.ObjectId;

const productIds = new Schema({
    'quantity': Number,
    '_id': ObjectId,
    'price': Number,
    'total': Number,
    'status': {
        type: String,
        enum: ['new', 'picked', 'delivered'],
        default: 'new'
    }
});

const orderPlace = new Schema({
    'total': Number,
    'paymentType': {
        type: String,
        enum: ['paypal', 'cash_on_delivery', 'bank_transfer'],
        default: 'cash_on_delivery'
    },
    'productIds': [productIds],
    'userId': {
        type: ObjectId,
        ref: 'euser'
    },
    'status': {
        type: String,
        enum: ['new', 'picked', 'delivered'],
        default: 'new'
    }
  
})

let orderModel = mongoose.model('orderPlace', orderPlace, 'orderPlace');

module.exports = orderModel;