const express = require('express');
const isEmpty = require('is-empty');
const router = express.Router();
const multer = require('multer')


// config
const passportAuth = require('../config/passport');

// validation
const userValid = require('../validation/user.validation');
const productValid = require('../validation/product.validation');
const euserValid =require('../validation/euser.validation');

// controllers
const userCtrl = require('../controllers/user.controller');
const categoryCtrl = require('../controllers/category.controller');
const productCtrl = require('../controllers/product.controller');
const carouselCtrl = require('../controllers/carousel.controller');
const euserCtrl = require('../controllers/euser.controller');


// config
const config = require('../config');

// MULTER
// const profileUpload = multer({ dest: 'public/profile/' });
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.IMAGE.USER_FILE_PATH)
    },
    filename: function (req, file, cb) {
        let mimeType =  file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + uniqueSuffix + '.' + fileType)
    }
})

const profileUpload = multer({ storage: storage })


// router.route('/register').post(userValid.registerValid, userCtrl.createUser);
// router.route('/login').post(userValid.loginValid, userCtrl.userLogin);
router.route('/forgetpassword').post(userValid.forgetpasswordValid, userCtrl.forgetPasswordctrl);
router.route('/update-user').post(passportAuth,profileUpload.single('image'), userValid.updateUservalid, userCtrl.updateUserctrl);
router.route('/find-user').get(passportAuth, userCtrl.findUserctrl);
router.route('/delete-user').post(passportAuth, userCtrl.deleteUserctrl);
router.route('/get-single-user/:userId').get(passportAuth, userCtrl.getSingleUser);
router.route('/changepassword').post(passportAuth, userValid.changepasswordValid, userCtrl.changePasswordctrl);
router.route('/resetpassword').post(userValid.resetpasswordValid, userCtrl.resetPassword);

// category
router.route('/get-category-one').get(categoryCtrl.getCategoryOne);
router.route('/category-list').get(categoryCtrl.getCategory);

// carousel
router.route('/carousel-list').get(carouselCtrl.getCarousel);

//product
router.route('/product-view-list/:categoryId').get(productCtrl.getProductView);
router.route('/get-product-detail/:id').get(productCtrl.getProductDetail);
router.route('/add-cart').post(passportAuth,productValid.createCartValid,productCtrl.createCart);
router.route('/get-cart').get(passportAuth, productCtrl.getCartProducts);
router.route('/delete-cart/:id').get(passportAuth,productCtrl.deletecartCtrl);

//euser
router.route('/euser-register').post(euserValid.createEuserValid,euserCtrl.createEUser);
router.route('/euser-login').post(euserValid.euserLoginValid,euserCtrl.euserLogin);
router.route('/euser-forgetpassword').post(euserValid.forgetpasswordValid, euserCtrl.forgetPassword);
router.route('/euser-resetpassword').post(euserValid.resetpasswordValid, euserCtrl.resetPassword);

//checkout
router.route('/check-out').post(passportAuth,productValid.createCheckoutValid,productCtrl.checkOut);

//contact
router.route('/contact').post(euserValid.createContactValid,euserCtrl.createContact);

//quiz
router.route('/get-quiz').post(euserCtrl.getQuiz);
router.route('/next-quiz').post(euserCtrl.nextQuestion);
router.route('/quiz-complete').get(euserCtrl.quizcomplete);
router.route('/quiz-reset').get(euserCtrl.resetTotalMarks);

module.exports = router;