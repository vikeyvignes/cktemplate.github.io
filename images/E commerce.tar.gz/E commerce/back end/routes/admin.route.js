const express = require('express');
const router = express.Router();
const multer = require('multer')


// config
const passportAuth = require('../config/passport');

// validation
const productValid = require('../validation/product.validation');
const categoryValid = require('../validation/category.validation');
const carouselValid = require('../validation/carousel.validation');
const euserValid = require('../validation/euser.validation');


// controllers
const productCtrl = require('../controllers/product.controller');
const categoryCtrl = require('../controllers/category.controller');
const carouselCtrl = require('../controllers/carousel.controller');
const euserCtrl = require('../controllers/euser.controller')


// config
const config = require('../config');



// MULTER
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.IMAGE.PRODUCT_FILE_PATH)
    },
    filename: function (req, file, cb) {
        let mimeType =  file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + uniqueSuffix + '.' + fileType)
    }
})

const productUpload = multer({ storage: storage })

const categorystorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.IMAGE.CATEGORY_FILE_PATH)
    },
    filename: function (req, file, cb) {
        let mimeType =  file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + uniqueSuffix + '.' + fileType)
    }
})

const categoryUpload = multer({ storage: categorystorage })


const carouselstorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.IMAGE.CAROUSEL_FILE_PATH)
    },
    filename: function (req, file, cb) {
        let mimeType =  file.mimetype;
        let split = mimeType.split('/');
        let fileType = split[1];
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + uniqueSuffix + '.' + fileType)
    }
})

const carouselUpload = multer({ storage: carouselstorage })

// products
router.route('/product-add').post(productUpload.single('image'), productValid.createProductvalid, productCtrl.createProduct);
router.route('/product-delete/:id').get(productCtrl.deleteproductCtrl);
router.route('/product-update').post(productUpload.single('image'), productValid.updateProductvalid, productCtrl.updateproductCtrl);
router.route('/product-list').get(productCtrl.getProducts);
router.route('/get-singleproduct/:id').get(productCtrl.getSingleProduct);
router.route('/status-update').post(productCtrl.statusUpdate);


// category
router.route('/category-add').post(categoryUpload.single('image'),categoryValid.CreatecategoryValid, categoryCtrl.createCategory);
router.route('/category-delete/:id').get(categoryCtrl.deletecategoryCtrl);
router.route('/category-update').post(categoryUpload.single('image'),categoryValid.updateCatergoryvalid, categoryCtrl.updatecategoryCtrl);
router.route('/category-list').get(categoryCtrl.getCategory);
router.route('/get-singlecategory/:id').get(categoryCtrl.getSingleCategory);


// carousel
router.route('/carousel-add').post(carouselUpload.single('image'),carouselValid.CreatecarouselValid, carouselCtrl.createCarousel);
router.route('/carousel-delete/:id').get(carouselCtrl.deletecarouselCtrl);
router.route('/carousel-update').post(carouselUpload.single('image'),carouselValid.updateCarouselvalid, carouselCtrl.updatecarouselCtrl);
router.route('/carousel-list').get(carouselCtrl.getCarousel);
router.route('/get-singlecarousel/:id').get(carouselCtrl.getSingleCarousel);

//contact
router.route('/contact-list').get(euserCtrl.getContact);

//cart
router.route('/cart-list').get(euserCtrl.getCartProducts);

//euser
router.route('/admin-login').post(euserValid.adminLoginValid,euserCtrl.adminLogin);

//orderplace
router.route('/order-list').get(euserCtrl.getOrderdetails);
router.route('/order-update').post(euserCtrl.orderUpdate);
router.route('/get-product-view/:orderId').get(euserCtrl.getProductView);

//message
router.route('/user-message').post(euserValid.messageValid,euserCtrl.userMessage);

//quiz
router.route('/create-quiz').post(euserValid.quizValid,euserCtrl.quiz);
module.exports = router;