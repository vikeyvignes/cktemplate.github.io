const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');

// Routes
const userRoutes = require('./routes/user.route');
const adminRoutes = require('./routes/admin.route');

// config
const config = require('./config');
const app = express();
const PORT = config.PORT;

// app.use
app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(cors())
app.use(express.static('public'))
app.use('/api', userRoutes);
app.use('/adminapi', adminRoutes);


const mongoConnect = async () => {
  try {
    await mongoose.connect('mongodb://localhost:27017/ecommerce', { useNewUrlParser: true });
    console.log('MONGO DB CONNECTED SUCCESSFULLY!')
  } catch (error) {
    console.log(error);
  }
}

mongoConnect()

app.listen(PORT, () => {
  console.log('SERVER IS RUNNING on ' + PORT)
})


