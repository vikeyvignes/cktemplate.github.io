// controller
const { jwtVerify } = require('../controllers/user.controller');

// models
const Euser = require('../models/euser');

const passportAuth = async (req, res, next) => {
   let decodedDoc = jwtVerify(req.headers.authorization);
   if(decodedDoc && decodedDoc.status === true){
      let checkUser = await Euser.findOne({ '_id' :  decodedDoc.decoded._id }).lean();
      if(!checkUser){
         return res.status(401).json({ 'status' : false, 'message' : 'Unauthorized user'})
      }

      req.user = { _id : decodedDoc.decoded._id };
      return next()
   }

   return res.status(401).json({ 'status' : false, 'message' : 'Unauthorized user'})
  
}

module.exports = passportAuth;