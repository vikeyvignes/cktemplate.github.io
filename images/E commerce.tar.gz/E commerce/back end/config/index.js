const PORT = 3005;
const API_URL = `http://localhost:${PORT}`;
let key = {
    'ADMIN_URL': 'http://localhost:3000',
    'API_URL': API_URL,
    'PORT': PORT,
    'SECRET_KEY': 'MERN_STACK',
    'IMAGE': {
        'PRODUCT_FILE_PATH': 'public/product/',
        'PRODUCT_FILE_URL_PATH': `${API_URL}/product`,
        'USER_FILE_PATH': 'public/profile/',
        'USER_FILE_URL_PATH': `${API_URL}/profile`,
        'CATEGORY_FILE_PATH': 'public/category/',
        'CATEGORY_FILE_URL_PATH': `${API_URL}/category`,
        'CAROUSEL_FILE_PATH': 'public/carousel/',
        'CAROUSEL_FILE_URL_PATH': `${API_URL}/carousel`,
    }
}

module.exports = key 