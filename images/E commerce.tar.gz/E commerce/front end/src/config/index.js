let API_URL = 'http://localhost:3005'
let keys = {
   'SERVER_URL' : `${API_URL}/api`,
   'IMAGE_URL' : API_URL
}

export default keys;