import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css';

// pages
import Home from './pages/Home';
import Shop from './pages/Shop';
import Contact from './pages/Contact';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Shopdetail from './pages/Shopdetail';
import Login from './pages/Login';
import Register from './pages/Register';
import Quiz from './pages/Quiz';
import QuizComplete from './pages/Quizcompelete';

//import Routes
import ConditionRoute from './Routes/conditionroute';

function App() {

  return (
    <div className="App">
      <BrowserRouter basename='/'>
        <Routes>
          <Route path='/' element={
            <ConditionRoute type="public">
              <Home />
            </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/home' element={
          <ConditionRoute type="public">
            <Home />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/quiz/:quizId' element={
          <ConditionRoute type="public">
            <Quiz />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/quiz-complete' element={
          <ConditionRoute type="public">
            <QuizComplete />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/login' element={
          <ConditionRoute type="public">
            <Login />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/register' element={
          <ConditionRoute type="public">
            <Register />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/shop/:categoryId' element={
          <ConditionRoute type="public">
            <Shop />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/contact' element={
          <ConditionRoute type="public">
            <Contact />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/shopdetail/:productId' element={
          <ConditionRoute type="public">
            <Shopdetail />
          </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/cart' element={
            <ConditionRoute type="private">
              <Cart />
            </ConditionRoute>}
          />
        </Routes>
        <Routes>
          <Route path='/checkout' element={
          <ConditionRoute type="private">
            <Checkout />
          </ConditionRoute>}
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
