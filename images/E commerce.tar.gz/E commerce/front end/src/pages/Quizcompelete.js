import React, { useState, useEffect } from 'react';
import { useNavigate,useParams} from 'react-router-dom';

//import Actions
import { quizcomplete, quizreset } from "../actions/userAction"

//import lib
import toastAlert from '../lib/toast';

const QuizComplete = () => {

    //navigate
    const navigate = useNavigate()
  // state
  const [reset, setReset] = useState([]);

 const completequiz = async () => {
    try {
   
      let { status, result } = await quizcomplete()
      if (status === true) {
        setReset(result)
      }
    } catch (err) {

    }
  }
  useEffect(() => {
    completequiz()
  }, [])
  const handleRetry = async () => {
    try {
   
      let { status, message } = await quizreset()
      if (status === true) {
        navigate('/quiz/'+1)
        toastAlert('success', message)
      }
    } catch (err) {

    }
   
  }
  return (

    <div>
      <div className="container-fluid pt-5 ">
      <div className="text-center mb-4">
          <h2 className="section-title px-5"><span className="px-2">Completed Successfully..!</span></h2>
        </div>
        <div className="text-center mb-4">
          <h2 className="section-title px-5"><span className="px-2">Total Marks = {reset.totalMark}</span></h2>
        </div>
         </div>
         <div>
        <button className="btn btn-primary py-2 px-4" type="button" onClick={handleRetry}>Retry</button>
      </div>
         </div>
  )
}

export default QuizComplete;