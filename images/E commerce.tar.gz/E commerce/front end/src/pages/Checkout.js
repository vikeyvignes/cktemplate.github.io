import React, { useState, useEffect } from 'react';

// import components
import ToolBar from '../components/common/ToolBar';
import NavBar from '../components/common/NavBar';
import Footer from "../components/common/Footer";

//import Actions
import { getCartProduct, checkOut } from '../actions/productAction';

const CheckoutPage = () => {

  const shippingCharge = 10;

  //state
  const [data, setData] = useState([]);
  const [subTotal, setSubTotal] = useState(0);
  const [paymentType, setPaymentType] = useState('');

  const getCart = async () => {
    try {
      let { status, result, total } = await getCartProduct()
      if (status == true) {
        setData(result)
        setSubTotal(total)
      }
    } catch (err) { }
  }

  const handleSubmit = async () => {

      let { status, message } = await checkOut({ paymentType });
      if(status === true) {
          alert(message)
      }
  } 

  const handleChange = (e) => {
    const { id } = e.target
    setPaymentType(id)
  }

  useEffect(() => {
    getCart()
  }, [])
  console.log(paymentType, 'payyyyyy')
  return (
    <div>
      {/* Topbar Start */}
      <ToolBar />
      {/* Topbar End */}
      {/* Navbar Start */}
      <NavBar />
      {/* Navbar End */}
      {/* Page Header Start */}
      <div className="container-fluid bg-secondary mb-5">
        <div className="d-flex flex-column align-items-center justify-content-center" style={{ minHeight: '300px' }}>
          <h1 className="font-weight-semi-bold text-uppercase mb-3">Checkout</h1>
          <div className="d-inline-flex">
            <p className="m-0"><a href>Home</a></p>
            <p className="m-0 px-2">-</p>
            <p className="m-0">Checkout</p>
          </div>
        </div>
      </div>
      {/* Page Header End */}
      {/* Checkout Start */}
      <div className="container-fluid pt-5">
        <div className="row px-xl-5">
          <div className="col-lg-8">
            <div className="mb-4">
              <h4 className="font-weight-semi-bold mb-4">Billing Address</h4>
              <div className="row">
                <div className="col-md-6 form-group">
                  <label>First Name</label>
                  <input className="form-control" type="text" placeholder="John" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Last Name</label>
                  <input className="form-control" type="text" placeholder="Doe" />
                </div>
                <div className="col-md-6 form-group">
                  <label>E-mail</label>
                  <input className="form-control" type="text" placeholder="example@email.com" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Mobile No</label>
                  <input className="form-control" type="text" placeholder="+123 456 789" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Address Line 1</label>
                  <input className="form-control" type="text" placeholder="123 Street" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Address Line 2</label>
                  <input className="form-control" type="text" placeholder="123 Street" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Country</label>
                  <select className="custom-select">
                    <option selected>United States</option>
                    <option>Afghanistan</option>
                    <option>Albania</option>
                    <option>Algeria</option>
                  </select>
                </div>
                <div className="col-md-6 form-group">
                  <label>City</label>
                  <input className="form-control" type="text" placeholder="New York" />
                </div>
                <div className="col-md-6 form-group">
                  <label>State</label>
                  <input className="form-control" type="text" placeholder="New York" />
                </div>
                <div className="col-md-6 form-group">
                  <label>ZIP Code</label>
                  <input className="form-control" type="text" placeholder={123} />
                </div>
                <div className="col-md-12 form-group">
                  {/* <div className="custom-control custom-checkbox">
                    <input type="checkbox" className="custom-control-input" id="newaccount" />
                    <label className="custom-control-label" htmlFor="newaccount">Create an account</label>
                  </div> */}
                </div>
                {/* <div className="col-md-12 form-group">
                  <div className="custom-control custom-checkbox">
                    <input type="checkbox" className="custom-control-input" id="shipto" />
                    <label className="custom-control-label" htmlFor="shipto" data-toggle="collapse" data-target="#shipping-address">Ship to different address</label>
                  </div>
                </div> */}
              </div>
            </div>
            <div className="collapse mb-4" id="shipping-address">
              <h4 className="font-weight-semi-bold mb-4">Shipping Address</h4>
              <div className="row">
                <div className="col-md-6 form-group">
                  <label>First Name</label>
                  <input className="form-control" type="text" placeholder="John" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Last Name</label>
                  <input className="form-control" type="text" placeholder="Doe" />
                </div>
                <div className="col-md-6 form-group">
                  <label>E-mail</label>
                  <input className="form-control" type="text" placeholder="example@email.com" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Mobile No</label>
                  <input className="form-control" type="text" placeholder="+123 456 789" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Address Line 1</label>
                  <input className="form-control" type="text" placeholder="123 Street" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Address Line 2</label>
                  <input className="form-control" type="text" placeholder="123 Street" />
                </div>
                <div className="col-md-6 form-group">
                  <label>Country</label>
                  <select className="custom-select">
                    <option selected>United States</option>
                    <option>Afghanistan</option>
                    <option>Albania</option>
                    <option>Algeria</option>
                  </select>
                </div>
                <div className="col-md-6 form-group">
                  <label>City</label>
                  <input className="form-control" type="text" placeholder="New York" />
                </div>
                <div className="col-md-6 form-group">
                  <label>State</label>
                  <input className="form-control" type="text" placeholder="New York" />
                </div>
                <div className="col-md-6 form-group">
                  <label>ZIP Code</label>
                  <input className="form-control" type="text" placeholder={123} />
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4">

            <div className="card border-secondary mb-5">
              <div className="card-header bg-secondary border-0">
                <h4 className="font-weight-semi-bold m-0">Order Total</h4>
              </div>
              <div className="card-body">
                <h5 className="font-weight-medium mb-3">Products</h5>
                {
                  data && data.length > 0 && data.map((item, key) => {
                    return (
                      <div key={key} className="d-flex justify-content-between">
                        <p>{item.productId && item.productId.name}</p>
                        <p>₹{item.total}</p>
                      </div>
                    )
                  })
                }
                <hr className="mt-0" />
                <div className="d-flex justify-content-between mb-3 pt-1">
                  <h6 className="font-weight-medium">Subtotal</h6>
                  <h6 className="font-weight-medium">₹{subTotal}</h6>
                </div>
                <div className="d-flex justify-content-between">
                  <h6 className="font-weight-medium">Shipping</h6>
                  <h6 className="font-weight-medium">₹{shippingCharge}</h6>
                </div>
              </div>
              <div className="card-footer border-secondary bg-transparent">
                <div className="d-flex justify-content-between mt-2">
                  <h5 className="font-weight-bold">Total</h5>
                  <h5 className="font-weight-bold">₹{subTotal + shippingCharge}</h5>
                </div>
              </div>
            </div>
            <div className="card border-secondary mb-5">
              <div className="card-header bg-secondary border-0">
                <h4 className="font-weight-semi-bold m-0">Payment</h4>
              </div>
              <div className="card-body">
                <div className="form-group">
                  <div className="">
                    <input type="radio" className="" onChange={handleChange} name="payment" id="paypal" checked={paymentType === 'paypal'} />
                    <label className="" htmlFor="paypal">Paypal</label>
                  </div>
                </div>
                <div className="form-group">
                  <div className="">
                    <input type="radio" className="" onChange={handleChange} name="payment" id="cash_on_delivery" checked={paymentType === 'cash_on_delivery'} />
                    <label className="" htmlFor="directcheck">Cash On Delivery</label>
                  </div>
                </div>
                <div className>
                  <div className="">
                    <input type="radio" className="" onChange={handleChange} name="payment" id="bank_transfer" checked={paymentType === 'bank_transfer'} />
                    <label className="" htmlFor="banktransfer">Bank Transfer</label>
                  </div>
                </div>
              </div>
              <div className="card-footer border-secondary bg-transparent">
                <button className="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3" onClick={handleSubmit}>Place Order</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Checkout End */}
      {/* Footer Start */}
      <Footer />
    </div>
  )
}

export default CheckoutPage;
