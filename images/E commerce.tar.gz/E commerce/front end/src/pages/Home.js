import React, { useRef, useEffect } from "react";

// import components
import ToolBar from '../components/common/ToolBar';
import HomeNavBar from '../components/common/HomeNavBar';
import Footer from "../components/common/Footer";
import CustomerService from '../components/CustomerService';
import CategoryView from '../components/CategoryView';


const Home = () => {
    const myRef = useRef()

    // useEffect(() => {
    //     myRef.current.test1();
    //     myRef.current.test();
    // }, [])
    return (
        <div>
            <ToolBar ref={myRef} />
            <HomeNavBar />
            <CustomerService />
            {/* Categories Start */}
            <CategoryView />

            {/* Subscribe Start */}
            <div className="container-fluid bg-secondary my-5">
                <div className="row justify-content-md-center py-5 px-xl-5">
                    <div className="col-md-6 col-12 py-5">
                        <div className="text-center mb-2 pb-2">
                            <h2 className="section-title px-5 mb-3"><span className="bg-secondary px-2">Stay Updated</span></h2>
                            <p>Amet lorem at rebum amet dolores. Elitr lorem dolor sed amet diam labore at justo ipsum eirmod duo labore labore.</p>
                        </div>
                        <form action>
                            <div className="input-group">
                                <input type="text" className="form-control border-white p-4" placeholder="Email Goes Here" />
                                <div className="input-group-append">
                                    <button className="btn btn-primary px-4">Subscribe</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    )
}
export default Home;