import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

//import actions
import { register } from '../actions/userAction';

// import lib
import toastAlert from '../lib/toast';

const initialFormValue = {
    'email': "",
    'phoneNo': "",
    'password': "",
    'confirmpassword': ""
}

const Register = () => {

    //navigate
    const navigate = useNavigate();

    //state
    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState([]);
    const { email, phoneNo, password, confirmpassword } = formValue

    const handleChange = (e) => {
        const { name, value } = e.target
        setFormValue({ ...formValue, ...{ [name]: value } })
    }

    const handleSubmit = async () => {
        try {
            let Data = {
                email: email,
                phoneNo: phoneNo,
                password: password,
                confirmpassword: confirmpassword
            }
            let { status, message, errors } = await register(Data)
            if (status == true) {
                toastAlert('success', message)
                setFormValue(initialFormValue)
                setErrors({})
                navigate('/login')
            } else if (status == false) {
                if (errors) {
                    setErrors(errors)
                }
                if (message) {
                    toastAlert('error', message)
                }
            }
        } catch (err) {

        }
    }

    return (
        <div>
            <div className="container-fluid">
                <div className="row align-items-center py-3 px-xl-5">
                    <div className="col-lg-3 d-none d-lg-block">
                        <a href className="text-decoration-none">
                            <h1 className="m-0 display-5 font-weight-semi-bold"><span className="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                        </a>
                    </div>
                </div>
            </div>
            <div className="container-fluid pt-5 ">
                <div className="text-center mb-4">
                    <h2 className="section-title px-5"><span className="px-2">Register Here</span></h2>
                </div>
                <div className="row px-xl-5">
                    <div className="col-lg-12 mb-5">
                        <div className="contact-form">
                            <div id="success" />
                            <form name="sentMessage" id="contactForm">
                                <div className="control-group">
                                    <input type="email" className="form-control" placeholder="Your Email" name="email" value={email} onChange={handleChange} />
                                    <span className='text-error'>{errors.email}</span><br />

                                </div>
                                <div className="control-group">
                                    <input type="phone" className="form-control" placeholder="Your phonenumber" name="phoneNo" value={phoneNo} onChange={handleChange} />
                                    <span className='text-error'>{errors.phoneNo}</span><br />

                                </div>
                                <div className="control-group">
                                    <input type="password" className="form-control" placeholder="Enter password" name="password" value={password} onChange={handleChange} />
                                    <span className='text-error'>{errors.password}</span><br />

                                </div>
                                <div className="control-group">
                                    <input type="password" className="form-control" placeholder="Re-enter password" name="confirmpassword" value={confirmpassword} onChange={handleChange} />
                                    <span className='text-error'>{errors.confirmpassword}</span><br />

                                </div>
                                <div>
                                    <button className="btn btn-primary py-2 px-4" type="button" id="sendMessageButton" onClick={handleSubmit} >Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Register;
