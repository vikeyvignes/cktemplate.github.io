import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

//import Actions
import { getQuizQuestions,getnextQuestions } from "../actions/userAction"

//import lib
import toastAlert from '../lib/toast';

const Quiz = () => {

  // hooks
  const navigate = useNavigate();

  //params
  const { quizId } = useParams();

  // state
  const [data, setData] = useState([]);
  const [selectedOption, setSelectedOption] = useState('');

  const getQuiz = async () => {
    try {
      let data = {
        _id: quizId
      }
      let { status, result } = await getQuizQuestions(data)
      if (status === true) {
        setData(result)
        setSelectedOption('');      
      }
    } catch (err) {

    }
  }
  const handleChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleNext = async () => {
    try {
      let Data = {
        questionNo : data.questionNo,
        selectedOption: selectedOption
      }
      let { status,message} = await getnextQuestions(Data)
      if (status === true) {
       if (data.questionNo <= 9) {
        navigate(`/quiz/${data.questionNo + 1}`)
      } else {
        navigate(`/quiz-complete`);
      }
    } else if (status === false) {
      toastAlert('error', message)
    }
    } catch (err) {
      
    }
 
  }
  const handleSubmit = () => {
    navigate('/quiz-complete')
  }

  useEffect(() => {
    getQuiz(quizId)
  }, [quizId],)

  return (

    <div>
      <div className="container-fluid pt-5 ">
        <div className="text-center mb-4">
          <h2 className="section-title px-5"><span className="px-2">{data.question}</span></h2>
        </div>
        <div className="card-body">
          <div className="form-group">
            <div className="">
              <input type="radio" className="" name={`options`} value={data.option1} onChange={handleChange} />
              <label className="" >{data.option1}</label>
            </div>
          </div>
          <div className="form-group">
            <div className="">
              <input type="radio" className="" name={`options`} value={data.option2} onChange={handleChange}/>
              <label className="" >{data.option2}</label>
            </div>
          </div>
          <div className>
            <div className="">
              <input type="radio" className="" name={`options`} value={data.option3} onChange={handleChange}/>
              <label className="">{data.option3}</label>
            </div>
          </div>
          <div className>
            <div className="">
              <input type="radio" className="" name={`options`} value={data.option4} onChange={handleChange}/>
              <label className="">{data.option4}</label>
            </div>
          </div>
        </div>
      </div>
      <div>
        <button className="btn btn-primary py-2 px-4" type="button" onClick={handleNext}  disabled={data.questionNo == 10 }>Next</button>
        <button className="btn btn-primary py-2 px-4 my-5 quizsubmit" type="button" onClick={handleSubmit} disabled={data.questionNo < 10}>Submit</button>
      </div>
    </div>
  )
}
export default Quiz;