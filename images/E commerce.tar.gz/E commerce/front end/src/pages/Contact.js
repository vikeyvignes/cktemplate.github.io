import React, { useState } from 'react'

// import components
import ToolBar from '../components/common/ToolBar';
import NavBar from '../components/common/NavBar';
import Footer from "../components/common/Footer";

//import actions
import { contact } from '../actions/userAction';

// import lib
import toastAlert from '../lib/toast';

const initialFormValue = {
    'email': "",
    'name': "",
    'message': "",
    'subject': ""
}

const Contact = () => {

    //state
    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState([]);
    const { email, name, subject, message } = formValue

    const handleChange = (e) => {
        const { name, value } = e.target
        setFormValue({ ...formValue, ...{ [name]: value } })
    }

    const handleSubmit = async () => {
        try {
            let Data = {
                email: email,
                name: name,
                subject: subject,
                message: message,
            }
            let { status, result, errors } = await contact(Data)
            if (status == true) {
                toastAlert('success', result)
                setFormValue(initialFormValue)
                setErrors({})
            } else if (status == false) {
                if (errors) {
                    setErrors(errors)
                }
                if (result) {
                    toastAlert('error', result)
                }
            }
        } catch (err) {

        }
    }


    return (
        <div>
            {/* Topbar Start */}
            <ToolBar />
            {/* Topbar End */}
            {/* Navbar Start */}
            <NavBar />
            {/* Navbar End */}
            {/* Page Header Start */}
            <div className="container-fluid bg-secondary mb-5">
                <div className="d-flex flex-column align-items-center justify-content-center" style={{ minHeight: '300px' }}>
                    <h1 className="font-weight-semi-bold text-uppercase mb-3">Contact Us</h1>
                    <div className="d-inline-flex">
                        <p className="m-0"><a href>Home</a></p>
                        <p className="m-0 px-2">-</p>
                        <p className="m-0">Contact</p>
                    </div>
                </div>
            </div>
            {/* Page Header End */}
            {/* Contact Start */}
            <div className="container-fluid pt-5">
                <div className="text-center mb-4">
                    <h2 className="section-title px-5"><span className="px-2">Contact For Any Queries</span></h2>
                </div>
                <div className="row px-xl-5">
                    <div className="col-lg-7 mb-5">
                        <div className="contact-form">
                            <div id="success" />
                            <form name="sentMessage" id="contactForm" noValidate="novalidate">
                                <div className="control-group">
                                    <input type="text" className="form-control" name="name" value={name} placeholder="Your Name" onChange={handleChange} />
                                    <span className='text-error'>{errors.name}</span><br />

                                </div>
                                <div className="control-group">
                                    <input type="email" className="form-control" name="email" value={email} placeholder="Your Email" onChange={handleChange} />
                                    <span className='text-error'>{errors.email}</span><br />

                                </div>
                                <div className="control-group">
                                    <input type="text" className="form-control" name="subject" value={subject} placeholder="Subject" onChange={handleChange} />
                                    <span className='text-error'>{errors.subject}</span><br />

                                </div>
                                <div className="control-group">
                                    <textarea className="form-control" rows={6} name="message" value={message} placeholder="Message" onChange={handleChange} defaultValue={""} />
                                    <span className='text-error'>{errors.message}</span><br />

                                </div>
                                <div>
                                    <button className="btn btn-primary py-2 px-4" type="button" onClick={handleSubmit}>Send
                                        Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div className="col-lg-5 mb-5">
                        <h5 className="font-weight-semi-bold mb-3">Get In Touch</h5>
                        <p>Justo sed diam ut sed amet duo amet lorem amet stet sea ipsum, sed duo amet et. Est elitr dolor elitr erat sit sit. Dolor diam et erat clita ipsum justo sed.</p>
                        <div className="d-flex flex-column mb-3">
                            <h5 className="font-weight-semi-bold mb-3">Store 1</h5>
                            <p className="mb-2"><i className="fa fa-map-marker-alt text-primary mr-3" />123 Street, New York, USA</p>
                            <p className="mb-2"><i className="fa fa-envelope text-primary mr-3" />info@example.com</p>
                            <p className="mb-2"><i className="fa fa-phone-alt text-primary mr-3" />+012 345 67890</p>
                        </div>
                        <div className="d-flex flex-column">
                            <h5 className="font-weight-semi-bold mb-3">Store 2</h5>
                            <p className="mb-2"><i className="fa fa-map-marker-alt text-primary mr-3" />123 Street, New York, USA</p>
                            <p className="mb-2"><i className="fa fa-envelope text-primary mr-3" />info@example.com</p>
                            <p className="mb-0"><i className="fa fa-phone-alt text-primary mr-3" />+012 345 67890</p>
                        </div>
                    </div>
                </div>
            </div>
            {/* Contact End */}
            {/* Footer Start */}
            <Footer />
        </div>

    )
}

export default Contact;