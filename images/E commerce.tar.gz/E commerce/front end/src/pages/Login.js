import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";


// import lib
import { setAuthToken } from '../lib/localstorage';
import toastAlert from '../lib/toast';

//import Actions
import { login } from "../actions/userAction"

//import config
import { setAuthorization } from '../config/axios'

const initialFormValue = {
    email: '',
    password: '',
}

const Login = () => {

    // hooks
    const navigate = useNavigate();

    // state
    const [formValue, setFormValue] = useState(initialFormValue);
    const [errors, setErrors] = useState({});
    const [passwordVisible, setPasswordVisible] = useState(false);

    const { email, password } = formValue;


    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValue({ ...formValue, ...{ [name]: value } })
    }

    const togglePasswordVisibility = () => {
        setPasswordVisible(!passwordVisible);
    }

    const handleSubmit = async () => {
        try {

            let data = {
                email: email,
                password: password
            }
            let { status, message, errors, token } = await login(data)
            if (status === true) {
                setFormValue(initialFormValue)
                setErrors({})
                setAuthToken(`Bearer ${token}`);
                setAuthorization(`Bearer ${token}`);
                toastAlert('success', message)
                navigate('/')
            } else if (status === false) {
                if (errors) {
                    setErrors(errors)
                } else if (message) {
                    toastAlert('error', message)
                }
            }

        } catch (err) {
            console.log(err, '...err')
        }
    }

    return (
        <div>
            <div className="container-fluid">
                <div className="row align-items-center py-3 px-xl-5">
                    <div className="col-lg-3 d-none d-lg-block">
                        <a href className="text-decoration-none">
                            <h1 className="m-0 display-5 font-weight-semi-bold"><span className="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                        </a>
                    </div>
                </div>
            </div>
            <div className="container-fluid pt-5 ">
                <div className="text-center mb-4">
                    <h2 className="section-title px-5"><span className="px-2">Login Here</span></h2>
                </div>
                <div className="row px-xl-5">
                    <div className="col-lg-12 mb-5">
                        <div className="contact-form">
                            <div id="success" />
                            <form name="sentMessage" id="contactForm" >
                                <div className="control-group">
                                    <input type="email" className="form-control" placeholder="Email/PhoneNumber" name='email' value={email} onChange={handleChange} />
                                    <span className='text-error'>{errors.email}</span><br />
                                </div>
                                <div className="control-group passwordgroup">
                                    <input
                                        type={passwordVisible ? "text" : "password"}
                                        className="form-control"
                                        placeholder="password"
                                        name="password"
                                        value={password}
                                        onChange={handleChange}
                                    />
                                    <span
                                        className="password-toggle"
                                        onClick={togglePasswordVisibility}
                                    >
                                        {passwordVisible ? (
                                            <FontAwesomeIcon icon={faEye} />
                                        ) : (
                                            <FontAwesomeIcon icon={faEyeSlash} />
                                        )}
                                    </span>
                                    <span className="text-error">{errors.password}</span>
                                </div>
                                <div className="login-button">
                                    <button className="btn btn-primary py-2 px-4" type="button" onClick={handleSubmit}>signin</button>
                                    <button className="btn btn-primary py-2 px-4 register-button" type="button" onClick={() => navigate('/register')}>New User?</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    )
}

export default Login;