import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";

// import actions
import { getCategoryOne } from '../../actions/productAction';

//import config
import { removeAuthorization } from '../../config/axios';

//import lib
import isLogin from '../../lib/isLogin';

const CommonNavBar = () => {

    //navigate
    const navigate = useNavigate();

    // location
    const { pathname } = useLocation();


    // state
    const [Id, setId] = useState('');
    const [email, setEmail] = useState('');

    const getData = async () => {
        const { status, result } = await getCategoryOne();
        if (status === true) {
            setId(result._id)
        }
    }

    const handleLogout = () => {

        removeAuthorization()


    }

    useEffect(() => {
        getData()
    }, []);

    return (
        <div className="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div className="navbar-nav mr-auto py-0">
                <Link to="/" className={`nav-item nav-link ${pathname === '/' && 'active'}`}>Home</Link>
                <Link to={"/shop/" + Id} className={`nav-item nav-link ${pathname === '/shop' && 'active'}`}>Shop</Link>
                <div className="nav-item dropdown">
                    <a href="#" className={`nav-link dropdown-toggle  ${['/cart', '/checkout'].includes(pathname) && 'active'} `} data-toggle="dropdown">Pages</a>
                    <div className="dropdown-menu rounded-0 m-0">
                        <Link to="/cart" className="dropdown-item">Shopping Cart</Link>
                        <Link to="/checkout" className="dropdown-item">Checkout</Link>
                    </div>

                </div>
                <Link to="/contact" className={`nav-item nav-link ${pathname === '/contact' && 'active'}`}>Contact</Link>
            </div>
            <div>
                <Link to={'/quiz/'+ 1}className="dropdown-item">Quiz</Link>
            </div>
            <div className="navbar-nav ml-auto py-0">
                {
                    !isLogin() && <Link to="/login" className={"nav-item nav-link"} >Login</Link>
                }

                {
                    isLogin() && <Link to="/login" onClick={handleLogout} className={"nav-item nav-link"} >Logout</Link>
                }
            </div>
        </div>
    )
}

export default CommonNavBar;