import React, { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";



// import actions
import { getCategory } from '../../actions/productAction';

const CategoryPage = () => {
    // location
    const { pathname } = useLocation()

    // state
    const [categoryData, setCategoryData] = useState([])

    const getData = async () => {
        try {
            const { status, result } = await getCategory();
            if (status === true) {
                setCategoryData(result)
            }
        } catch (err) {
            console.log(err, 'errr')
        }
    }

    useEffect(() => {
        getData()
    }, [])

    return (
        <div className="col-lg-3 d-none d-lg-block">
            <a className="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100" data-toggle="collapse" href="#navbar-vertical" style={{ height: '65px', marginTop: '-1px', padding: '0 30px' }}>
                <h6 className="m-0">Categories</h6>
                <i className="fa fa-angle-down text-dark" />
            </a>
            <nav className={`collapse ${pathname == '/' ? 'show' : 'position-absolute'} navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0`} id="navbar-vertical">
                <div className="navbar-nav w-100 overflow-hidden" style={{ height: '410px' }}>
                    {
                        categoryData && categoryData.length > 0 && categoryData.map((item, i) => {
                            return (
                                <Link to={'/shop/' + item._id } key={i} className="nav-item nav-link">{item.name}</Link>
                            )
                        })
                    }
                </div>
            </nav>
        </div>
    )
}

export default CategoryPage;