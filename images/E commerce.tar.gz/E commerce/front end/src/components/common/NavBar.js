import React from "react";
import { Link, useLocation } from "react-router-dom";

// import components
import CategoryPage from "./CategoryPage";
import CommonNavBar from "./CommonNavbar";

const NavBar = () => {

    // location
    const { pathname } = useLocation();

    return (
        <div className="container-fluid">
            <div className="row border-top px-xl-5">
                <CategoryPage />
                <div className="col-lg-9">
                    <nav className="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                        <a href className="text-decoration-none d-block d-lg-none">
                            <h1 className="m-0 display-5 font-weight-semi-bold"><span className="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                        </a>
                        <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span className="navbar-toggler-icon" />
                        </button>
                        <CommonNavBar />
                    </nav>
                </div>
            </div>
        </div>
    )
}

export default NavBar;