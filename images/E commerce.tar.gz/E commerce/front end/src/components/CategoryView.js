import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom';

// import actions
import { getCategory } from '../actions/productAction';

const CategoryView = () => {

    // navigate
    const navigate = useNavigate();

    // state
    const [categoryData, setCategoryData] = useState([])
    const [imageLink, setImageLink] = useState([])

    const getData = async () => {
        try {
            const { status, result, imageUrl } = await getCategory();
            if (status === true) {
                setCategoryData(result)
                setImageLink(imageUrl)
            }
        } catch (err) {
            console.log(err, 'errr')
        }
    }

    useEffect(() => {
        getData()
    }, [])

    return (
        <div className="container-fluid pt-5">
            <div className="row px-xl-5 pb-3">
                {
                    categoryData && categoryData.length > 0 && categoryData.map((item, key) => {
                        return (
                            <div key={key} className="col-lg-4 col-md-6 pb-1" onClick={() => navigate(`/shop/${item._id}`)}>
                                <div className="cat-item d-flex flex-column border mb-4" style={{ padding: '30px' }}>
                                    <p className="text-right">15 Products</p>
                                    <a href className="cat-img position-relative overflow-hidden mb-3">
                                        <img className="img-fluid" src={`${imageLink}/${item.image}`} alt="" />
                                    </a>
                                    <h5 className="font-weight-semi-bold m-0">{item.name}</h5>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default CategoryView;