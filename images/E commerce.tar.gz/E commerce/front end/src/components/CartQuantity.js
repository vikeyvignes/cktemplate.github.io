import React, { useEffect, useState } from 'react';

//importActions
import { addCart } from '../actions/productAction';

const CartQuantity = ({ data, getCart }) => {
    // console.log(props, 'propspropsprops')
    const [quantity, setQuantity] = useState(0);

    const addQuantity = async () => {
        let updateQuan = quantity + 1;
        let dataObj = {
            'quantity': updateQuan,
            'productId': data.productId._id
        }
        let { status, message } = await addCart(dataObj)
        if (status == true) {
            // alert('added')
            setQuantity(updateQuan)
            getCart()
        }
      
    };

    const subQuantity = async () => {
        let updateQuan = quantity - 1;
        let dataObj = {
            'quantity': updateQuan,
            'productId': data.productId._id
        }
        let { status, message } = await addCart(dataObj)
        if (status == true) {
            // alert('sub')
            setQuantity(updateQuan)
            getCart()
        }
       
    };

    useEffect(() => {
        setQuantity(data.quantity)
    }, [])

    return (
        <div className="input-group quantity mx-auto" style={{ width: '100px' }}>
            <div className="input-group-btn">
                <button
                    className="btn btn-sm btn-primary btn-minus"
                    onClick={subQuantity}
                >
                    <i className="fa fa-minus" />
                </button>
            </div>
            <input
                type="text"
                className="form-control form-control-sm bg-secondary text-center"
                value={quantity}
            />
            <div className="input-group-btn">
                <button
                    className="btn btn-sm btn-primary btn-plus"
                    onClick={addQuantity}
                >
                    <i className="fa fa-plus" />
                </button>
            </div>
        </div>
    )
}

export default CartQuantity;