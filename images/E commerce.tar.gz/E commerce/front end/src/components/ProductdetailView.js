import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom'

//importActions
import { getProductDetail, addCart } from '../actions/productAction';


//import lib
import toastAlert from '../lib/toast'
import isLogin from '../lib/isLogin'

const ProductdetailView = () => {


  // navigate
  const navigate = useNavigate();

  //params
  const { productId} = useParams();

  // state
  const [data, setData] = useState([])
  const [imageLink, setImageLink] = useState([])
  const [count, setCount] = useState(1);

  const ProductDetail = async (productId) => {
    try {
      const { status, result, imageUrl } = await getProductDetail(productId);
      if (status === true) {
        setData(result)
        setImageLink(imageUrl)
      }
    } catch (err) {
      console.log(err, 'errr')
    }
  }


  useEffect(() => {
    ProductDetail(productId)
  }, [])

  const handleChange = async () => {
    if(!isLogin()) return navigate('/login')
    try {
      let Data = {
        productId: data._id,
        quantity: count,
       
      }

      let { status, message } = await addCart(Data);
      if (status == true) {
        toastAlert('success', message)
        navigate('/cart')
      }
    } catch (err) {
      console.log(err, 'errrrrr')
    }

  }

  console.log(data, 'dataa')
  return (
    <div className="container-fluid py-5">
      <div className="row px-xl-5">
        <div className="col-lg-5 pb-5">
          <div id="product-carousel" className="carousel slide" data-ride="carousel">
            <div className="carousel-inner border">
              <div className="carousel-item active">
                <img className="w-100 h-100" src={`${imageLink}/${data.image}`} alt="Image" />
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-7 pb-5">
          <h3 className="font-weight-semi-bold">{data.name}</h3>
          <div className="d-flex mb-3">
            <div className="text-primary mr-2">
              <small className="fas fa-star" />
              <small className="fas fa-star" />
              <small className="fas fa-star" />
              <small className="fas fa-star-half-alt" />
              <small className="far fa-star" />
            </div>
            <small className="pt-1">(50 Reviews)</small>
          </div>
          <h3 className="font-weight-semi-bold mb-4">${data.price}</h3>
          <p className="mb-4">{data.description}</p>
          <div className="d-flex align-items-center mb-4 pt-2">
            <div className="input-group quantity mr-3" style={{ width: '130px' }}>
              <div className="input-group-btn">
                <button className="btn btn-primary btn-minus" onClick={() => {
                  if (count > 1) {
                    setCount(count - 1)
                  }
                }} disabled={count <= 1}>
                  <i className="fa fa-minus" />
                </button>
              </div>
              <input type="text" className="form-control bg-secondary text-center" value={count} />
              <div className="input-group-btn">
                <button className="btn btn-primary btn-plus" onClick={() => {
                  if (count < data.availableQty)
                    setCount(count + 1)
                }} disabled={count == data.availableQty}>
                  <i className="fa fa-plus" />
                </button>
              </div>
            </div>
            <button className="btn btn-primary px-3" onClick={handleChange}><i className="fa fa-shopping-cart mr-1" /> Add To Cart</button>
          </div>
          <div className="d-flex pt-2">
            <p className="text-dark font-weight-medium mb-0 mr-2">Share on:</p>
            <div className="d-inline-flex">
              <a className="text-dark px-2" href>
                <i className="fab fa-facebook-f" />
              </a>
              <a className="text-dark px-2" href>
                <i className="fab fa-twitter" />
              </a>
              <a className="text-dark px-2" href>
                <i className="fab fa-linkedin-in" />
              </a>
              <a className="text-dark px-2" href>
                <i className="fab fa-pinterest" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
export default ProductdetailView;