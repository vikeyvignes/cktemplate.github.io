import React, { useState, useEffect } from 'react';
import { useLocation } from "react-router-dom";


// import actions
import { getCarousel } from '../actions/productAction';

const CarouselView = () => {


    // location
    const { pathname } = useLocation();

    // state
    const [carouselData, setCarouselData] = useState([])
    const [imageLink, setImageLink] = useState([])

    const getData = async () => {
        try {
            const { status, result, imageUrl } = await getCarousel();
            if (status === true) {
                setCarouselData(result)
                setImageLink(imageUrl)
            }
        } catch (err) {
            console.log(err, 'errr')
        }
    }

    useEffect(() => {
        getData()
    }, [])




    return (

        <div id="header-carousel" className="carousel slide" data-ride="carousel">
            <div className="carousel-inner">

                {
                    carouselData && carouselData.length > 0 && carouselData.map((item, i) => {

                        return (

                            <div key={i} className={i == 0 ? 'carousel-item active' : 'carousel-item'} style={{ height: '410px' }}>
                                <img className="img-fluid" src={`${imageLink}/${item.image}`} alt="Image" />
                                <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                    <div className="p-3" style={{ maxWidth: '700px' }}>
                                        <h4 className="text-light text-uppercase font-weight-medium mb-3">{item.offername}</h4>
                                        <h3 className="display-4 text-white font-weight-semi-bold mb-4">{item.name}</h3>
                                        <a href className="btn btn-light py-2 px-3">Shop Now</a>
                                    </div>
                                </div>
                            </div>

                        )
                    })
                }
            </div>
            <a className="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div className="btn btn-dark" style={{ width: '45px', height: '45px' }}>
                    <span className="carousel-control-prev-icon mb-n2" />
                </div>
            </a>
            <a className="carousel-control-next" href="#header-carousel" data-slide="next">
                <div className="btn btn-dark" style={{ width: '45px', height: '45px' }}>
                    <span className="carousel-control-next-icon mb-n2" />
                </div>
            </a>
        </div>

    );

}

export default CarouselView;