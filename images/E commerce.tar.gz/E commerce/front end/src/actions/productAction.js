// import axios
import axios from '../config/axios';

export const getCategory = async () => {
    try {
        let respData = await axios({

            'url': '/category-list',
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
        }

    } catch (err) {
        console.log(err, 'errrr')
    }
}

export const getProductView = async (categoryId) => {
    try {
        let respData = await axios({

            'url': '/product-view-list/' + categoryId,
            'method': 'get',

        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,

        }
    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }

}

export const getCarousel = async () => {
    try {
        let respData = await axios({
            'url': '/carousel-list',
            'method': 'get',
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}

export const getCategoryOne = async () => {
    try {
        let respData = await axios({
            'url': '/get-category-one',
            'method': 'get',
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result
        }

    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}

export const getProductDetail = async (productId) => {
    try {
        let respData = await axios({
            'url': '/get-product-detail/' + productId,
            'method': 'get',
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}

export const addCart = async (Data) => {
    try {
        let respData = await axios({
            'url': '/add-cart',
            'method': 'post',
            data : Data
        })
    
        return {
            'status': respData.data.status,
            'message': respData.data.message
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}

export const getCartProduct = async () => {
    try {
        let respData = await axios({
            'url': '/get-cart' ,
            'method': 'get',
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
            'imageUrl': respData.data.imageUrl,
            'total': respData.data.total,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}

export const deleteCart = async (id) => {
    try {
        let respData = await axios({
            'url': '/delete-cart/' + id,
            'method': 'get',
            
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}

export const checkOut = async (data) => {
    try {
        let respData = await axios({
            'url': '/check-out',
            'method': 'post',
            data
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}