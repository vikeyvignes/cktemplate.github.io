import axios from '../config/axios';


export const register = async (Data) => {

    try {
        let respData = await axios({
            'url': '/euser-register',
            'method': 'post',
             data: Data 
        })
        return {
            'status': respData.data.status,
            'message': respData.data.message
        }

    } catch (err) {
        return {
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors
        }
    }

}

export const login = async (data) => {

    try {
        let respData = await axios({
            'url': '/euser-login',
            'method': 'post',
            data
        })
        return {
            'status': respData.data.status,
            'message': respData.data.message,
            'token' : respData.data.token
        }
    } catch (err) {
        return{
            'status': err.response.data.status,
            'message': err.response.data.message,
            'errors': err.response.data.errors
        }
    }
}

export const contact = async (Data) => {

    try {
        let respData = await axios({
            'url': '/contact',
            'method': 'post',
             data: Data 
        })
        return {
            'status': respData.data.status,
            'result': respData.data.result
        }

    } catch (err) {
        return {
            'status': err.response.data.status,
            'result': err.response.data.result,
            'errors': err.response.data.errors
        }
    }

}
export const getQuizQuestions = async (data) => {
    try {
        let respData = await axios({
            'url': '/get-quiz',
            'method': 'post',
            data
            
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}
export const getnextQuestions = async (Data) => {
    try {
        let respData = await axios({
            'url': '/next-quiz',
            'method': 'post',
            'data':Data
            
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}
export const quizcomplete = async () => {
    try {
        let respData = await axios({
            'url': '/quiz-complete',
            'method': 'get',    
        })

        return {
            'status': respData.data.status,
            'result': respData.data.result,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}
export const quizreset = async () => {
    try {
        let respData = await axios({
            'url': '/quiz-reset',
            'method': 'get',    
        })

        return {
            'status': respData.data.status,
            'message': respData.data.message,
        }

    } catch (err) {
        console.log(err, 'errrr')
        return {
            'status': err.response.data.status,
            'message': err.response.data.message
        }
    }
}